# Supplemental Data S2

Evaluation data and code for Training Context Construction and Calibration for Evidence Gating in Retrieval Augmented Question Answering.

## Reproduce the reported analysis

Extract S2 and S3 into sibling directories. With Python 3.10+ and NumPy, run `python reproduce_statistics.py` from S2. It reproduces the HotpotQA classification, fixed-reader answer metrics, risk curves and 5,000-draw paired component bootstrap, followed by all NoMIRACL and SQuAD2 external metrics and four paired bootstrap contrasts. It uses the actual saved scores; numerical reproduction requires no model download, training or GPU. Original outputs remain in `reported_analysis` and `external/reported`.

## Main experiment

`evaluation` contains 21,024 frozen scored inputs, 22 score arrays (462,528 probabilities), all 10,112 fixed-reader outputs, retrieval groups and input hashes. No reader output was selected by correctness. `code/data` supplies the frozen 62,838-passage HotpotQA corpus, construction records and the original evaluation modules. CE, NR, CH and NH map to CE, NAT_RANDOM_CE, CORE_HARD_CE and RET_CE in raw keys. Three matched fits are repeated model fits, not independent questions. `restore_inputs.py` reconstructs dictionary-encoded passage identities and value-only corpora, checks exact original byte hashes and runs automatically. No original text, score, label or grouping value is rounded or discarded. S3 provides training inputs and portable refitting entry points; large public pretrained weights and derived adapters are outside these size-limited archives.

## Independent public-label validation

`external/inputs.npz` contains every original source identifier, published label, calibration/test assignment, component, token count and input hash in frozen plan order: 834 NoMIRACL calibration + 2,132 full English test inputs and 2,000 SQuAD2 training calibration + 11,873 full official development inputs. `external/scores.npz` contains all 202,068 actual probabilities from twelve frozen fits. Float32 storage is lossless for these original values: exact float64 round-trip equality was verified. `external/protocol.json`, source-file hashes, exclusions, preparation audit, model-control check, actual run environment and timing summary are included. No annotation by the manuscript authors enters this reported validation. Original benchmark annotations define relevance/answerability; the main task retains its separate support-coverage definition.

Run `python external/reproduce_external.py` for external numerical analysis only. The script compares every metric and all four sets of 5,000 bootstrap draws against the server outputs. Reconstructed cache files contain scores and completion flags only; actual run timings are preserved in summary/environment records.

To recover exact source text and token inputs, obtain the eleven official files listed in `external/raw_manifest.json`, preserving its NoMIRACL_english and SQuAD2 subdirectories, then run:

`python external/restore_public_inputs.py --raw-root PATH --output reconstructed_inputs`

The optional `--download` flag obtains missing files from those frozen official URLs. Optional `--tokenizer-file PATH_TO_QWEN_TOKENIZER_JSON` additionally checks every prompt token hash and the complete original token binary hash (requires the tokenizers library). Without that option it still reconstructs the exact original plan bytes and verifies their SHA256. Official SQuAD2 development data is the external test here; the hidden official test set is not used. Model-visible SQuAD2 documents contain the original paragraph and an empty title; original titles are grouping metadata.

## Sources and formats

MuSiQue: https://github.com/stonybrooknlp/musique ; HotpotQA: https://hotpotqa.github.io/ ; IIRC: https://github.com/jferguson144/IIRC-baseline ; NoMIRACL: https://huggingface.co/datasets/miracl/nomiracl ; SQuAD2: https://rajpurkar.github.io/SQuAD-explorer/ . Text and models retain their providers' terms. NoMIRACL publication DOI: 10.18653/v1/2024.findings-emnlp.730. SQuAD2 publication DOI: 10.18653/v1/P18-2124. `SHA256SUMS.json` identifies all files except itself.

Some original members use standard ZIP LZMA compression. Extract with Python `python -m zipfile -e Supplemental_Data_S2.zip .` or a compatible extractor. New compact NPZ arrays require no pickle. Historical journal names in frozen protocols identify their creation context; the submission destination is PeerJ Computer Science.
