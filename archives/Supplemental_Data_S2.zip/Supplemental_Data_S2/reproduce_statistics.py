"""Reproduce main-task and public-label external numerical results."""
from pathlib import Path
import subprocess
import sys
HERE = Path(__file__).resolve().parent
from restore_inputs import restore
restore(HERE)
sys.path.insert(0, str(HERE / 'code'))
import analyze
from common import read
print('Recomputing main-task metrics and 5000 paired draws.', flush=True)
analyze.analyze(HERE / 'evaluation', read(HERE / 'code/protocol.json'), make_plots=False)
subprocess.run([sys.executable, str(HERE / 'external/reproduce_external.py')], check=True)
print('ALL_REPORTED_NUMERICAL_ANALYSES_PASS', flush=True)
