"""Frozen calibration policies and paired whole-component inference; no test tuning."""
import csv
from collections import defaultdict
from common import *

BASE = Path(__file__).resolve().parent
POLICIES = ['source_mu12', 'target12', 'target40', 'bm25_target40_transfer', 'fixed_half']


def csv_write(path, records):
    if not records:
        return
    fields = list(dict.fromkeys(k for r in records for k in r))
    with Path(path).open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(records)


def configuration_method(key):
    return key.rsplit('_seed', 1)[0] if '_seed' in key else key


def analyze(root, cfg, make_plots=True):
    root = Path(root)
    out = root / 'analysis'
    out.mkdir(exist_ok=True)
    plan = rows(root / 'evaluation_plan.jsonl')
    labels = np.array([r['label'] for r in plan])
    probabilities = {}
    for path in sorted((root / 'score_cache').glob('*.npz')):
        with np.load(path, allow_pickle=False) as cache:
            assert cache['done'].all() and len(cache['probability']) == len(plan)
            p = cache['probability'].copy()
            assert np.isfinite(p).all() and ((p >= 0) & (p <= 1)).all()
            probabilities[path.stem] = p
    assert len(probabilities) == 22
    strata = defaultdict(list)
    for i, row in enumerate(plan):
        strata[(row['cohort'], row['retriever'], row['split'], row['condition'])].append(i)
    strata = {k: np.array(v) for k, v in strata.items()}
    source = np.array([i for i, r in enumerate(plan) if r['cohort'] == 'source'])
    assert len(source) == 800
    undefined = []

    def safe_cut(p, indices, name):
        try:
            return cutoff(p[indices], labels[indices])
        except ValueError as error:
            undefined.append(dict(location=name, reason=str(error)))
            return None

    thresholds, classification, curves, qa, rocs = {}, [], [], [], []
    answers = {(r['group_id'], r['retriever'], r['condition']): r for r in rows(root / 'shared_answers.jsonl')}
    assert len(answers) == 10112
    for key, p in probabilities.items():
        source_cut = safe_cut(p, source, key + ':source')
        old_cuts = read(BASE / 'data/source_cutoffs.json')
        if key in old_cuts:
            assert abs(source_cut - old_cuts[key]) < 1e-12
        for cohort in ['v5_seen', 'v6_unseen']:
            for retriever in ['BM25', 'HYBRID_RRF']:
                cuts = {'source_mu12': source_cut, 'fixed_half': .5}
                for policy, retr, condition in [('target12', retriever, 'n12'), ('target40', retriever, 'n40'), ('bm25_target40_transfer', 'BM25', 'n40')]:
                    indices = strata[(cohort, retr, 'calibration', condition)]
                    cuts[policy] = safe_cut(p, indices, ':'.join([key, cohort, retriever, policy]))
                thresholds[':'.join([key, cohort, retriever])] = cuts
                for condition in ['n12', 'n20', 'n32', 'n40']:
                    indices = strata[(cohort, retriever, 'test', condition)]
                    ident = dict(configuration=key, method=configuration_method(key), cohort=cohort, retriever=retriever, condition=condition)
                    rocs.append(dict(ident, **roc_points(labels[indices], p[indices])))
                    for policy, cut in cuts.items():
                        if cut is None:
                            continue
                        classification.append(dict(ident, policy=policy, **metrics(labels[indices], p[indices], cut)))
                    if condition not in ['n12', 'n40']:
                        continue
                    em, f1 = [], []
                    for i in indices:
                        answer = answers[(plan[i]['group_id'], retriever, condition)]
                        e, f = answer_metrics(answer['candidate'], answer['references'])
                        em.append(e)
                        f1.append(f)
                    em, f1 = np.array(em), np.array(f1)
                    curve = selection_curve(p[indices], em)
                    curves.append(dict(ident, inputs=len(indices), all_EM=float(em.mean()), **curve))
                    for policy, cut in cuts.items():
                        if cut is None:
                            continue
                        accept = p[indices] >= cut
                        qa.append(dict(ident, policy=policy, inputs=len(indices), accepted=int(accept.sum()), acceptance=float(accept.mean()),
                            all_EM=float(em.mean()), all_F1=float(f1.mean()), conditional_EM=float(em[accept].mean()) if accept.any() else None,
                            conditional_F1=float(f1[accept].mean()) if accept.any() else None, matched_accepted_yield=float((em * accept).mean()),
                            unmatched_accepted_yield=float(((1-em) * accept).mean()), empty_retained=sum(not answers[(plan[i]['group_id'], retriever, condition)]['candidate'] for i in indices)))
    # Means / seed SD are descriptive across the three matched fits, never a CI.
    grouped = defaultdict(list)
    groupkeys = ['method', 'cohort', 'retriever', 'condition', 'policy']
    for r in classification:
        grouped[tuple(r[k] for k in groupkeys)].append(r)
    aggregate = []
    for identity, members in grouped.items():
        row = dict(zip(groupkeys, identity), fits=len(members))
        for metric in ['AUROC', 'FAR', 'TPR', 'acceptance', 'Brier']:
            values = [m[metric] for m in members if m[metric] is not None]
            row[metric + '_mean'] = float(np.mean(values)) if values else None
            row[metric + '_seed_SD'] = float(np.std(values, ddof=1)) if len(values) > 1 else None
        aggregate.append(row)
    csv_write(out / 'classification_per_fit.csv', classification)
    csv_write(out / 'classification_aggregate.csv', aggregate)
    csv_write(out / 'answer_metrics.csv', qa)
    save(out / 'thresholds.json', thresholds)
    save(out / 'selection_curves.json', curves)
    save(out / 'ROC_points.json', rocs)
    # Raw score vectors remain in score_cache; plot source includes both classes.
    primary = primary_intervals(plan, labels, probabilities, strata, source, cfg)
    save(out / 'primary_four_endpoints.json', primary)
    save(out / 'undefined_statistics.json', undefined)
    description = '''# 分析边界

v5_seen 的所有新增分析为已见队列上的探索；v6_unseen 是补充方案冻结后首次评分的保留来源组件，仍来自同一 HotpotQA 数据源。来源支持材料与训练不交叉，不代表骨干预训练或历史检索背景绝无曝光。

标签表示原标注支持材料全部覆盖，不等于独立语义充分性。EM 不匹配不等于已证实幻觉。空答、长度上限回答保留在分母中。

阈值只由校准标签确定。source_mu12 为原 MuSiQue n12 正类 TPR 目标 0.8；target12/40 使用对应队列和检索器的独立校准集；bm25_target40_transfer 复用同队列 BM25 n40 阈值。均接受 score>=threshold，平分可能使校准 TPR 超过 0.8。fixed_half 为 0.5。

主比较：v6_unseen / HYBRID_RRF / n40，NAT_RANDOM_CE 减 CE，在 source_mu12 与 target40 下分别比较 FAR 和 TPR，共四端点。5000 次来源组件配对抽样；target40 另独立抽样校准组件并在每次抽样中重新求各拟合阈值。三个匹配种子先分别计算后平均。报告普通95%与Bonferroni四端点区间；不涵盖重新训练和开发选点不确定性。若某抽样缺少必要类别，明确报告不可估计，不删题或依据性能中断队列。

只有 target40 的 FAR 差校正区间上界<0 且 TPR 差校正区间下界>-0.02，才满足本补充方案的联合实用性标准；未满足不能声称等效或无损。该标准不是预先功效保证，也不是通过/失败后追加实验的触发器。

曲线按同一批共享回答、相同接受预算计算，分数平分采用期望随机打破；AURC 枚举每个保留数量。图中三种子SD属于描述性离散度。长度/词面逻辑回归和自写零样本提示是诊断参照，不是 MemSafe 或 Sufficient Context 原论文复现。独立人工审核仍待完成。
'''
    (out / '分析说明.md').write_text(description, encoding='utf-8')
    plot_status = 'not_requested'
    if make_plots:
        try:
            from figures import make_figures
        except ModuleNotFoundError as error:
            if not error.name.startswith('matplotlib'):
                raise
            plot_status = 'pending_local_render_missing_matplotlib'
            save(out / 'plot_status.json', dict(status=plot_status, raw_plot_data_complete=True, missing_dependency=error.name))
            print('PLOTS PENDING LOCAL RENDER: matplotlib absent; all scores/statistics/curve data are complete.', flush=True)
        else:
            make_figures(out, aggregate, curves, plan, probabilities)
            plot_status = 'drafts_generated_visual_QA_pending'
    return dict(classification_rows=len(classification), answer_rows=len(qa), curves=len(curves), primary=primary['status'], undefined=len(undefined), plots=plot_status)


def primary_intervals(plan, labels, probabilities, strata, source, cfg):
    test = strata[('v6_unseen', 'HYBRID_RRF', 'test', 'n40')]
    cal = strata[('v6_unseen', 'HYBRID_RRF', 'calibration', 'n40')]
    rng = np.random.default_rng(202611011)
    draws = cfg['bootstrap_draws']
    wt = component_weights([plan[i] for i in test], draws, rng)
    wc = component_weights([plan[i] for i in cal], draws, rng)
    endpoints = []
    try:
        for policy in ['source_mu12', 'target40']:
            differences = {'FAR': [], 'TPR': []}
            points = {'FAR': [], 'TPR': []}
            for seed in SEEDS:
                rates, observed = {}, {}
                for method in ['CE', 'NAT_RANDOM_CE']:
                    p = probabilities[f'{method}_seed{seed}']
                    c = cutoff(p[source if policy == 'source_mu12' else cal], labels[source if policy == 'source_mu12' else cal])
                    cuts = np.full(draws, c) if policy == 'source_mu12' else boot_cutoffs(p[cal], labels[cal], wc)
                    rates[method] = boot_rates(p[test], labels[test], cuts, wt)
                    observed[method] = metrics(labels[test], p[test], c)
                for metric in differences:
                    if observed['CE'][metric] is None or observed['NAT_RANDOM_CE'][metric] is None:
                        raise ValueError('Observed fresh primary stratum has an absent class')
                    differences[metric].append(rates['NAT_RANDOM_CE'][metric] - rates['CE'][metric])
                    points[metric].append(observed['NAT_RANDOM_CE'][metric] - observed['CE'][metric])
            for metric in differences:
                values = np.mean(differences[metric], axis=0)
                endpoints.append(dict(policy=policy, metric=metric, contrast='NAT_RANDOM_CE minus CE', difference=float(np.mean(points[metric])),
                    CI95=np.quantile(values, [.025, .975]).tolist(), CI_family4=np.quantile(values, [.00625, .99375]).tolist()))
        joint = {r['metric']: r for r in endpoints if r['policy'] == 'target40'}
        utility = joint['FAR']['CI_family4'][1] < 0 and joint['TPR']['CI_family4'][0] > -.02
        return dict(status='estimable', draws=draws, test_questions=len(test), calibration_questions=len(cal), endpoints=endpoints,
            target40_joint_utility_supported=bool(utility), scope='conditional on existing fits; source cutoff fixed; target40 calibration resampled')
    except ValueError as error:
        return dict(status='nonestimable', reason=str(error), endpoints=endpoints, draws=draws, target40_joint_utility_supported=None)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    print(analyze(args.output, read(BASE / 'protocol.json')))
