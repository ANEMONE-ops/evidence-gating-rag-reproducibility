"""Optional complete 12-fit reproduction of the original four-corner training.

Separate from the default supplement, which reuses the fixed trained weights.
"""
import argparse
import sys
import tarfile
from common import *

BASE = Path(__file__).resolve().parent


def safe_extract(archive, destination):
    destination = Path(destination).resolve()
    destination.mkdir(parents=True, exist_ok=True)
    with tarfile.open(archive, 'r:gz') as source:
        members = source.getmembers()
        for member in members:
            target = (destination / member.name).resolve()
            assert target.is_relative_to(destination) and not member.issym() and not member.islnk() and (member.isfile() or member.isdir()), 'Unsafe archive member'
        source.extractall(destination, members=members)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    from run import validate
    validate()
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=True)
    identity = dict(protocol_sha256=sha(BASE / 'protocol.json'), row_map_sha256=sha(BASE / 'data/four_corner_training_maps.jsonl'))
    if (root / 'identity.json').exists():
        assert read(root / 'identity.json') == identity, 'Output directory belongs to different training inputs'
    else:
        save(root / 'identity.json', identity)
    lock = (root / 'run.lock').open('w')
    import fcntl
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    extracted = root / 'frozen_source'
    if not (extracted / 'paper4_06_formal_v5/protocol.json').exists():
        safe_extract(BASE / 'reproduction/frozen_v5.tar.gz', extracted)
    original = extracted / 'paper4_06_formal_v5'
    # The frozen original modules and optimizer remain untouched.
    sys.path.insert(0, str(original))
    import run_v3 as train
    import legacy_runner as engine
    import adapters
    import tasks
    cfg = read(original / 'protocol.json')
    plan = rows(original / 'plan.jsonl')
    tokens = np.memmap(original / 'token_ids.bin', mode='r', dtype='<i4')
    maps = rows(BASE / 'data/four_corner_training_maps.jsonl')
    queue = [dict(method=m, seed=s) for m in METHODS for s in SEEDS]
    cfg.update(queue=queue, methods=METHODS)
    model, tokenizer, info = engine.load_model()
    adapters.install(model, cfg['rank'], cfg['alpha'])
    # All four are CE objectives; their six global training rows differ.
    for method in METHODS:
        tasks.METHODS[method] = []
    save(root / 'training_protocol.json', dict(cfg, source_sha256=sha(BASE / 'reproduction/frozen_v5.tar.gz'), row_map_sha256=sha(BASE / 'data/four_corner_training_maps.jsonl')))
    for i, job in enumerate(queue):
        method, seed = job['method'], job['seed']
        groups = [dict(g, global_rows=g['global_rows_by_method'][method]) for g in maps]
        assert len(groups) == 5426 and sum(len(g['global_rows']) for g in groups) == 32556
        result, path = train.train_one(model, tokens, plan, groups, cfg, root, method, seed, i)
        save(root / 'completed_runs' / f'{method}_seed{seed}.json', dict(result=result, weight=str(path)))
    print('ALL 12 OPTIONAL REPRODUCTION FITS COMPLETE. Original weights preserved.', flush=True)


if __name__ == '__main__':
    main()
