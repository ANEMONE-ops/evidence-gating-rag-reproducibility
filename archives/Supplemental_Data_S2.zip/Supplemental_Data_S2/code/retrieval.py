"""Pinned offline dense embeddings and equal-weight BM25/dense rank fusion."""
from collections import Counter, defaultdict
from pathlib import Path
import math

import numpy as np
from common import QUERY_PREFIX, atomic_npz, digest, lines, read, save, sha, terms


def top_indices(scores, count):
    scores = np.asarray(scores)
    count = min(count, len(scores))
    boundary = np.partition(scores, len(scores) - count)[len(scores) - count]
    candidates = np.flatnonzero(scores >= boundary)
    return candidates[np.lexsort((candidates, -scores[candidates]))[:count]]


def build_bm25(corpus, questions, progress=print):
    keys = sorted(corpus)
    vocabulary = {term for question in questions for term in terms(question)}
    postings = defaultdict(lambda: [[], []])
    lengths = np.empty(len(keys), dtype=float)
    for i, key in enumerate(keys):
        counts = Counter(terms(corpus[key]['title'] + ' ' + corpus[key]['text']))
        lengths[i] = sum(counts.values())
        for term in vocabulary.intersection(counts):
            postings[term][0].append(i)
            postings[term][1].append(counts[term])
        if (i + 1) % 10000 == 0:
            progress('BM25_INDEX', i + 1, '/', len(keys))
    average = max(float(lengths.mean()), 1.)
    result = {}
    for term, (positions, frequency) in postings.items():
        positions, frequency = np.asarray(positions), np.asarray(frequency, dtype=float)
        idf = math.log1p((len(keys) - len(positions) + .5) / (len(positions) + .5))
        weights = frequency * 2.5 / (frequency + 1.5 * (.25 + .75 * lengths[positions] / average)) * idf
        result[term] = positions, weights
    return keys, result


def bm25_search(question, index, count=256):
    keys, postings = index
    scores = np.zeros(len(keys), dtype=float)
    for term in sorted(set(terms(question))):
        if term in postings:
            positions, weights = postings[term]
            scores[positions] += weights
    chosen = top_indices(scores, count)
    return chosen, scores[chosen]


def fuse(sparse, dense, count=40, rank_constant=60):
    values = defaultdict(float)
    for ranking in [sparse, dense]:
        for rank, index in enumerate(ranking, 1):
            values[int(index)] += 1 / (rank_constant + rank)
    chosen = sorted(values, key=lambda i: (-values[i], i))[:count]
    return chosen, [values[i] for i in chosen]


def encode_texts(model, tokenizer, texts, prefix, target, progress, name):
    import torch
    target = Path(target)
    status = target.with_suffix('.progress.json')
    identity = digest('\n'.join(texts) + '\n' + prefix)
    if target.exists():
        state = read(status)
        assert state['identity'] == identity and state['max_length'] == 512
        values = np.lib.format.open_memmap(target, mode='r+')
    else:
        values = np.lib.format.open_memmap(target, mode='w+', dtype=np.float32, shape=(len(texts), 384))
        state = dict(identity=identity, max_length=512, completed=0, truncated_indices=[])
        save(status, state)
    assert values.shape == (len(texts), 384)
    for start in range(state['completed'], len(texts), 64):
        batch_text = [prefix + text for text in texts[start:start + 64]]
        original = tokenizer(batch_text, padding=False, truncation=False, return_length=True)
        for index, length in enumerate(original['length']):
            if length > 512:
                state['truncated_indices'].append(start + index)
        batch = tokenizer(batch_text, padding=True, truncation=True, max_length=512, return_tensors='pt').to('cuda:0')
        with torch.inference_mode():
            output = model(**batch).last_hidden_state[:, 0].float()
            embedding = torch.nn.functional.normalize(output, p=2, dim=1).cpu().numpy()
        assert np.isfinite(embedding).all() and np.allclose(np.linalg.norm(embedding, axis=1), 1, atol=1e-5)
        values[start:start + len(embedding)] = embedding
        values.flush()
        state['completed'] = start + len(embedding)
        save(status, state)
        if state['completed'] % 1024 == 0 or state['completed'] == len(texts):
            progress(name, state['completed'], '/', len(texts), 'embedding truncations', len(state['truncated_indices']))
    return values, state


def retrieve_all(base, root, groups, corpus, progress=print):
    import torch
    from transformers import AutoModel, AutoTokenizer
    output = root / 'retrieval_groups.jsonl'
    if output.exists():
        from common import rows
        result = rows(output)
        assert len(result) == len(groups) and [g['group_id'] for g in result] == [g['group_id'] for g in groups]
        return result
    cache = root / 'embedding_cache'
    cache.mkdir(exist_ok=True)
    progress('LOAD_PINNED_BGE', 'offline fixed FP32 encoder')
    tokenizer = AutoTokenizer.from_pretrained(base / 'embedding_model', local_files_only=True, trust_remote_code=False)
    model = AutoModel.from_pretrained(base / 'embedding_model', local_files_only=True, trust_remote_code=False, torch_dtype=torch.float32, use_safetensors=True).eval().to('cuda:0')
    torch.backends.cuda.matmul.allow_tf32 = False
    keys = sorted(corpus)
    documents = [corpus[key]['title'] + '\n' + corpus[key]['text'] for key in keys]
    document_values, document_state = encode_texts(model, tokenizer, documents, '', cache / 'documents.npy', progress, 'EMBED_CORPUS')
    query_values, query_state = encode_texts(model, tokenizer, [g['question'] for g in groups], QUERY_PREFIX, cache / 'queries.npy', progress, 'EMBED_QUERIES')
    save(root / 'embedding_audit.json', dict(model='BAAI/bge-small-en-v1.5', revision='5c38ec7c405ec4b44b94cc5a9bb96e735b38267a', pooling='CLS', normalization='L2', precision='FP32', query_prefix=QUERY_PREFIX, documents=len(keys), queries=len(groups), document_truncation_indices=document_state['truncated_indices'], query_truncation_indices=query_state['truncated_indices'], max_embedding_tokens=512, generator_text_truncation=False, weight_sha256=sha(base / 'embedding_model/model.safetensors')))
    del model
    torch.cuda.empty_cache()
    index = build_bm25(corpus, [g['question'] for g in groups], progress)
    assert index[0] == keys
    document_tensor = torch.from_numpy(np.asarray(document_values)).to('cuda:0')
    result = []
    for start in range(0, len(groups), 32):
        query_tensor = torch.from_numpy(np.asarray(query_values[start:start + 32])).to('cuda:0')
        with torch.inference_mode():
            scores = (query_tensor @ document_tensor.T).cpu().numpy()
        for j, g in enumerate(groups[start:start + 32]):
            sparse, sparse_scores = bm25_search(g['question'], index)
            dense = top_indices(scores[j], 256)
            combined, fusion_scores = fuse(sparse, dense)
            sparse_keys = [keys[i] for i in sparse[:40]]
            if g['cohort'] == 'v5_seen':
                assert sparse_keys == g['retrieved_keys'], 'Original BM25 did not reproduce ' + g['group_id']
            result.append(dict(g, retrievals={
                'BM25': dict(document_keys=sparse_keys, retrieval_scores=[float(v) for v in sparse_scores[:40]]),
                'HYBRID_RRF': dict(document_keys=[keys[i] for i in combined], retrieval_scores=fusion_scores),
            }))
        progress('RETRIEVED', len(result), '/', len(groups), 'BM25 and HYBRID_RRF')
    del document_tensor, query_tensor
    torch.cuda.empty_cache()
    lines(output, result)
    return result
