"""One resumable supplement queue. No performance gates and no GPU retraining."""
import os
for name, value in {'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1', 'OMP_NUM_THREADS': '8', 'OPENBLAS_NUM_THREADS': '8', 'MKL_THREADING_LAYER': 'SEQUENTIAL', 'PYTORCH_CUDA_ALLOC_CONF': 'max_split_size_mb:128'}.items():
    os.environ.setdefault(name, value)
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import shutil
import signal
import sys
import threading
import time
import traceback
import zipfile

import numpy as np
from common import *

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / 'legacy'))


def validate(base=BASE):
    cfg = read(base / 'protocol.json')
    assert cfg['version'] == 'paper4_electronics_supplement_v6'
    for name, expected in cfg['files_sha256'].items():
        path = (base / name).resolve()
        assert path.is_relative_to(base.resolve()) and sha(path) == expected, 'Changed package member ' + name
    groups = rows(base / 'data/groups.jsonl')
    assert len(groups) == 2528 and len({g['group_id'] for g in groups}) == 2528
    assert {(cohort, split): sum(g['cohort'] == cohort and g['split'] == split for g in groups) for cohort, split in [('v5_seen', 'calibration'), ('v5_seen', 'test'), ('v6_unseen', 'calibration'), ('v6_unseen', 'test')]} == {('v5_seen', 'calibration'): 400, ('v5_seen', 'test'): 1200, ('v6_unseen', 'calibration'): 300, ('v6_unseen', 'test'): 628}
    for cohort in ['v5_seen', 'v6_unseen']:
        cal = {g['component_id'] for g in groups if g['cohort'] == cohort and g['split'] == 'calibration'}
        test = {g['component_id'] for g in groups if g['cohort'] == cohort and g['split'] == 'test'}
        assert not cal & test
    assert len(rows(base / 'data/source_records.jsonl')) == 800
    assert cfg['performance_gate'] is False and cfg['new_gpu_training_fits'] == 0
    return cfg, groups


def build_inputs(root, retrieved, corpus, tokenizer, progress):
    import core
    plan_path = root / 'evaluation_plan.jsonl'
    token_dir = root / 'token_inputs'
    token_dir.mkdir(exist_ok=True)
    if plan_path.exists():
        plan = rows(plan_path)
        assert len(plan) == 21024
        return plan
    original = {r['sample_id']: r for r in rows(BASE / 'data/old_records.jsonl')}
    original_by_group = {(r['group_id'], r['condition']): r for r in original.values()}
    corpus = {**corpus, **read(BASE / 'data/source_corpus.json')}
    records = []
    for group in retrieved:
        for retriever in ['BM25', 'HYBRID_RRF']:
            for size in SIZES:
                condition = f'n{size}'
                keys = group['retrievals'][retriever]['document_keys'][:size]
                old = original_by_group.get((group['group_id'], condition)) if retriever == 'BM25' else None
                records.append(dict(sample_id=f'{retriever}:{group["cohort"]}:{group["group_id"]}:{condition}', original_sample_id=old['sample_id'] if old else None,
                    group_id=group['group_id'], component_id=group['component_id'], cohort=group['cohort'], split=group['split'], retriever=retriever,
                    question=group['question'], references=group['references'], condition=condition, document_keys=keys,
                    label=int(set(group['required']) <= set(keys)), expected_old_hash=old['input_sha256'] if old else None))
    for row in rows(BASE / 'data/source_records.jsonl'):
        records.append(dict(row, original_sample_id=row['sample_id'], sample_id='source:' + row['sample_id'], references=[], expected_old_hash=row['input_sha256']))
    cached = document_features(corpus)
    feature_rows = []
    offsets = {'standard': 0, 'sufficiency': 0}
    from contextlib import ExitStack
    with ExitStack() as stack:
        streams = {name: stack.enter_context((token_dir / f'{name}.bin').open('wb')) for name in offsets}
        for index, record in enumerate(records):
            docs = [corpus[key] for key in record['document_keys']]
            messages = core.messages(record['question'], docs)
            for variant in offsets:
                if variant == 'sufficiency':
                    messages[0]['content'] = SUFFICIENCY_SYSTEM
                ids = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
                assert 0 < len(ids) <= 12288, 'Whole input exceeds fixed cap; do not silently truncate or replace questions'
                blob = np.asarray(ids, dtype='<i4').tobytes()
                import hashlib
                signature = hashlib.sha256(blob).hexdigest()
                record[variant] = dict(offset=offsets[variant], tokens=len(ids), input_sha256=signature)
                streams[variant].write(blob)
                offsets[variant] += len(ids)
                if variant == 'standard' and record['expected_old_hash']:
                    assert signature == record['expected_old_hash'], 'Frozen input changed ' + record['sample_id']
            feature_rows.append(features(record['question'], record['document_keys'], record['standard']['tokens'], cached))
            record.pop('expected_old_hash')
            if (index + 1) % 500 == 0:
                progress('RENDER_INPUTS', index + 1, '/', len(records))
    atomic_npz(root / 'evaluation_features.npz', features=np.asarray(feature_rows))
    lines(plan_path, records)
    save(root / 'render_audit.json', dict(inputs=len(records), old_input_hash_matches=7200, max_prompt_tokens={name: max(r[name]['tokens'] for r in records) for name in offsets}, truncated_inputs=0, dropped_questions=0, token_file_sha256={name: sha(token_dir / f'{name}.bin') for name in offsets}))
    return records


def cache_identity(root, key, signature, variant, plan):
    folder = root / 'score_cache'
    folder.mkdir(exist_ok=True)
    path = folder / f'{key}.npz'
    identity = dict(configuration=key, model_signature=signature, variant=variant, plan_sha256=sha(root / 'evaluation_plan.jsonl'), inputs=len(plan))
    identity_path = path.with_suffix('.json')
    if identity_path.exists():
        assert read(identity_path) == identity, 'Stale cache identity ' + key
    else:
        assert not path.exists(), 'Cache has no identity ' + key
        save(identity_path, identity)
    if path.exists():
        with np.load(path, allow_pickle=False) as cache:
            return path, {name: cache[name].copy() for name in ['probability', 'done', 'latency_ms', 'reused']}
    values = dict(probability=np.zeros(len(plan)), done=np.zeros(len(plan), dtype=bool), latency_ms=np.zeros(len(plan)), reused=np.zeros(len(plan), dtype=bool))
    if key in FITTED + ['prompt_base_seed0']:
        old = rows(BASE / 'data/old_records.jsonl') + rows(BASE / 'data/source_records.jsonl')
        lookup = {r['sample_id']: i for i, r in enumerate(old)}
        with np.load(BASE / 'data/old_predictions.npz', allow_pickle=False) as cache:
            scores = cache[key]
        for i, record in enumerate(plan):
            if record['original_sample_id'] in lookup:
                values['probability'][i] = scores[lookup[record['original_sample_id']]]
                values['done'][i] = values['reused'][i] = True
    return path, values


def predict(model, plan, tokens, root, key, signature, variant, progress):
    import torch
    import adapters
    import legacy_runner as engine
    path, values = cache_identity(root, key, signature, variant, plan)
    completed_at_start = int(values['done'].sum())
    progress('SCORE_START', key, completed_at_start, '/', len(plan))
    if values['reused'].any():
        probe = int(np.flatnonzero(values['reused'])[0])
        with torch.inference_mode():
            result = float(torch.softmax(adapters.binary_logits(model, engine.input_tensor(tokens, plan[probe][variant])), 0)[1])
        error = abs(result - values['probability'][probe])
        assert error < .001, 'Frozen weight/control did not reproduce ' + key
        save(root / 'control_checks' / (key + '.json'), dict(configuration=key, sample_id=plan[probe]['sample_id'], absolute_error=error, tolerance=.001))
    model.eval()
    try:
        with torch.inference_mode():
            for index, record in enumerate(plan):
                if values['done'][index]:
                    continue
                torch.cuda.synchronize()
                started = time.perf_counter()
                value = float(torch.softmax(adapters.binary_logits(model, engine.input_tensor(tokens, record[variant])), 0)[1])
                torch.cuda.synchronize()
                assert math.isfinite(value) and 0 <= value <= 1
                values['probability'][index] = value
                values['latency_ms'][index] = (time.perf_counter() - started) * 1000
                values['done'][index] = True
                if (index + 1) % 100 == 0:
                    atomic_npz(path, **values)
                    progress('SCORING', key, int(values['done'].sum()), '/', len(plan))
    finally:
        atomic_npz(path, **values)
    assert values['done'].all()
    return dict(configuration=key, inputs=len(plan), reused=int(values['reused'].sum()), newly_scored=int((~values['reused']).sum()), new_inference_seconds=float(values['latency_ms'][~values['reused']].sum() / 1000))


def diagnostic_heads(root, plan, progress):
    with np.load(BASE / 'data/diagnostic_training_features.npz', allow_pickle=False) as data:
        x, y = data['features'], data['labels']
        evaluation = np.load(root / 'evaluation_features.npz', allow_pickle=False)['features']
        heads = {}
        for method in METHODS:
            for kind, columns in [('LENGTH', [0, 1, 2, 3]), ('LEXICAL', list(range(len(FEATURES))))]:
                key = kind + '__' + method
                ix = data[method]
                head = fit_logistic(x[ix], y[ix], columns)
                heads[key] = head
                p = head_predict(head, evaluation)
                atomic_npz(root / 'score_cache' / (key + '.npz'), probability=p, done=np.ones(len(p), dtype=bool), latency_ms=np.zeros(len(p)), reused=np.zeros(len(p), dtype=bool))
                progress('CPU_DIAGNOSTIC_HEAD', key, 'all', len(ix), 'original training views')
    save(root / 'diagnostic_heads.json', dict(models=heads, features=FEATURES, warning='Diagnostic shortcut comparators fitted on each matching frozen construction, not reproductions of MemSafe or Sufficient Context'))


def generate_shared_answers(model, tokenizer, retrieved, corpus, root, progress):
    import torch
    from tasks import answer_messages
    cache_dir = root / 'answer_cache'
    cache_dir.mkdir(exist_ok=True)
    old = {r['sample_id']: r for r in rows(BASE / 'data/old_answers.jsonl')}
    result = []
    for group in retrieved:
        for retriever in ['BM25', 'HYBRID_RRF']:
            for size in [12, 40]:
                condition = f'n{size}'
                sample_id = f'{retriever}:{group["cohort"]}:{group["group_id"]}:{condition}'
                filename = digest(sample_id) + '.json'
                path = cache_dir / filename
                keys = group['retrievals'][retriever]['document_keys'][:size]
                messages = answer_messages(group['question'], [corpus[key] for key in keys])
                ids = tokenizer.apply_chat_template(messages, tokenize=True, add_generation_prompt=True)
                import hashlib
                signature = hashlib.sha256(np.asarray(ids, dtype='<i4').tobytes()).hexdigest()
                if path.exists():
                    answer = read(path)
                    assert answer['sample_id'] == sample_id and answer['input_sha256'] == signature
                else:
                    original_id = 'fresh_v5:' + group['group_id'] + ':' + condition
                    if retriever == 'BM25' and group['cohort'] == 'v5_seen' and original_id in old:
                        answer = dict(old[original_id], sample_id=sample_id, reused=True)
                        assert answer['input_sha256'] == signature
                    else:
                        x = torch.tensor([ids], dtype=torch.long, device='cuda:0')
                        torch.cuda.synchronize()
                        started = time.perf_counter()
                        with torch.inference_mode():
                            generated = model.generate(input_ids=x, attention_mask=torch.ones_like(x), max_new_tokens=64, do_sample=False, use_cache=True, num_logits_to_keep=1,
                                temperature=1., top_p=1., top_k=50, pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id, eos_token_id=tokenizer.eos_token_id)
                        torch.cuda.synchronize()
                        output = generated[0, len(ids):].tolist()
                        text = tokenizer.decode(output, skip_special_tokens=True)
                        answer = dict(sample_id=sample_id, input_sha256=signature, candidate=text.strip(), raw_text=text, generated_token_ids=output, generated_tokens=len(output),
                            hit_token_cap=len(output) == 64 and (not output or output[-1] != tokenizer.eos_token_id), reused=False, latency_ms=(time.perf_counter() - started) * 1000)
                    save(path, answer)
                result.append(dict(answer, group_id=group['group_id'], cohort=group['cohort'], split=group['split'], retriever=retriever, condition=condition, references=group['references']))
                if len(result) % 50 == 0:
                    progress('SHARED_ANSWERS', len(result), '/', 10112)
    assert len(result) == 10112
    lines(root / 'shared_answers.jsonl', result)
    save(root / 'answer_audit.json', dict(outputs=len(result), reused=sum(r['reused'] for r in result), newly_generated=sum(not r['reused'] for r in result), empty=sum(not r['candidate'] for r in result), capped=sum(r['hit_token_cap'] for r in result), all_outputs_retained=True, meaning='EM-unmatched is not independently verified factual error'))


def archive(root):
    path = root.parent / (root.name + '_results.zip')
    temporary = path.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as target:
        for source in sorted(root.rglob('*')):
            relative = source.relative_to(root)
            if source.is_file() and not set(relative.parts) & {'embedding_cache', 'token_inputs', 'answer_cache'} and source.name != 'run.lock' and not source.name.endswith('.tmp'):
                target.write(source, relative.as_posix())
        for source in sorted(BASE.glob('*.py')):
            target.write(source, 'execution_code/' + source.name)
        target.write(BASE / 'protocol.json', 'execution_code/protocol.json')
        target.write(BASE / 'data/source_cutoffs.json', 'execution_code/data/source_cutoffs.json')
        target.write(BASE / '实验方案与证据边界.md', 'execution_code/实验方案与证据边界.md')
    temporary.replace(path)
    print('RESULT_ARCHIVE:', path, flush=True)
    print('RESULT_SHA256:', sha(path), flush=True)
    return path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=Path('/root/autodl-tmp/paper4_supplement_v6'))
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    print('PAPER4 SUPPLEMENT V6: validating fixed package; full queue continues regardless of effects.', flush=True)
    cfg, groups = validate()
    if args.self_test:
        from self_check import main as check
        check()
        return
    root = args.output.resolve()
    root.mkdir(parents=True, exist_ok=True)
    lock = (root / 'run.lock').open('w')
    if os.name == 'posix':
        import fcntl
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    signature = sha(BASE / 'protocol.json')
    if (root / 'identity.json').exists():
        assert read(root / 'identity.json')['protocol_sha256'] == signature, 'Output belongs to another protocol'
    else:
        save(root / 'identity.json', dict(protocol_sha256=signature))
    print('LIVE_RESULTS_DIR:', root, flush=True)
    if (root / 'summary.json').exists() and read(root / 'summary.json').get('automated_completed'):
        print('AUTOMATED QUEUE ALREADY COMPLETE; preserving results.', flush=True)
        archive(root)
        return
    started = time.perf_counter()
    stage = {'name': 'environment', 'updated': time.time()}
    stopped = threading.Event()
    def progress(*parts):
        message = ' '.join(map(str, parts))
        stage.update(name=message, updated=time.time())
        print(datetime.now(timezone.utc).isoformat(), message, flush=True)
        save(root / 'progress.json', dict(stage=message, elapsed_hours=(time.perf_counter() - started) / 3600, utc=datetime.now(timezone.utc).isoformat()))
    def heartbeat():
        while not stopped.wait(30):
            print('HEARTBEAT', stage['name'], 'stage silence seconds', round(time.time() - stage['updated']), flush=True)
    threading.Thread(target=heartbeat, daemon=True).start()
    report = dict(status='running', automated_completed=False, independent_human_review='pending', gpu_training_fits=0, errors=[])
    save(root / 'summary.json', report)
    def interrupted(signum, frame):
        raise KeyboardInterrupt('Signal ' + str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    try:
        import torch
        import importlib.metadata as metadata
        assert torch.cuda.is_available(), 'Use the existing verified GPU server'
        assert torch.__version__.startswith('2.1.2') and metadata.version('transformers') == '4.45.2', 'Expected existing verified torch2.1.2/transformers4.45.2 environment; do not silently upgrade'
        torch.set_num_threads(8)
        torch.manual_seed(20261101)
        from retrieval import retrieve_all
        corpus = read(BASE / 'data/hot_corpus.json')
        retrieved = retrieve_all(BASE, root, groups, corpus, progress)
        import legacy_runner as engine
        import adapters
        progress('LOAD_QWEN', 'existing cached fixed backbone')
        model, tokenizer, info = engine.load_model()
        save(root / 'model_loading_info.json', info)
        plan = build_inputs(root, retrieved, corpus, tokenizer, progress)
        streams = {name: np.memmap(root / 'token_inputs' / f'{name}.bin', mode='r', dtype='<i4') for name in ['standard', 'sufficiency']}
        completions = []
        for key, variant in [('prompt_base_seed0', 'standard'), ('sufficiency_prompt_seed0', 'sufficiency')]:
            completions.append(predict(model, plan, streams[variant], root, key, 'zero_updates:' + cfg['qwen_revision'], variant, progress))
        adapters.install(model, 8, 16)
        for key in FITTED:
            weight = BASE / 'weights' / (key + '.pt')
            adapters.load_adapter(model, torch.load(weight, map_location='cpu', weights_only=False))
            completions.append(predict(model, plan, streams['standard'], root, key, sha(weight), 'standard', progress))
            save(root / 'scoring_completion.json', completions)
        with torch.no_grad():
            for module in model.modules():
                if hasattr(module, 'a') and hasattr(module, 'b'):
                    module.b.zero_()
        model.eval()
        diagnostic_heads(root, plan, progress)
        generate_shared_answers(model, tokenizer, retrieved, corpus, root, progress)
        del model
        torch.cuda.empty_cache()
        from analyze import analyze
        progress('FULL_ANALYSIS', 'calibration, curves, fresh paired component intervals')
        analysis = analyze(root, cfg)
        shutil.copytree(BASE / 'human_review', root / 'human_review', dirs_exist_ok=True)
        report.update(status='automated_completed_human_review_pending', automated_completed=True, independent_human_review='pending_not_replaced_by_model_labels', binary_configurations=len(QWEN_KEYS) + 8,
            binary_inputs_per_configuration=len(plan), qwen_new_binary_scores=sum(r['newly_scored'] for r in completions), qwen_reused_binary_scores=sum(r['reused'] for r in completions),
            cpu_diagnostic_heads=8, answers=10112, invocation_hours=(time.perf_counter() - started) / 3600, analysis=analysis)
        save(root / 'summary.json', report)
        progress('AUTOMATED_COMPLETE', 'Independent human labels remain pending; see human_review/')
    except BaseException as error:
        report.update(status='interrupted' if isinstance(error, KeyboardInterrupt) else 'failed', automated_completed=False,
            failed_stage=stage['name'], invocation_hours=(time.perf_counter() - started) / 3600)
        report['errors'].append(dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc()))
        save(root / 'summary.json', report)
        print(traceback.format_exc(), flush=True)
        raise
    finally:
        stopped.set()
        archive(root)


if __name__ == '__main__':
    main()
