"""Meaningful CPU checks. Does not claim a remote GPU experiment."""
import tempfile
from pathlib import Path
import numpy as np
from common import *

BASE = Path(__file__).resolve().parent


def main(full_bm25=False):
    checks = []
    def passed(name):
        checks.append(name)
    # Pairwise definition independently checks ties and direction.
    y = np.array([0, 1, 0, 1, 1, 0])
    p = np.array([.1, .7, .7, .7, .9, .1])
    expected = np.mean([float(a > b) + .5 * float(a == b) for a in p[y == 1] for b in p[y == 0]])
    assert abs(auc(y, p) - expected) < 1e-12 and auc(np.ones(3), np.arange(3)) is None
    passed('AUROC pairwise ties and missing class')
    c = cutoff(p, y)
    assert c == .7 and (p[y == 1] >= c).mean() >= .8
    passed('Positive quantile and inclusive ties')
    w = np.array([[1, 2, 0, 1, 1, 1], [0, 1, 2, 2, 1, 0]])
    cuts = boot_cutoffs(p, y, w)
    for i in range(2):
        ix = np.repeat(np.arange(6), w[i])
        assert cuts[i] == cutoff(p[ix], y[ix])
        rates = boot_rates(p, y, cuts, w)
        direct = metrics(y[ix], p[ix], cuts[i])
        assert all(abs(rates[k][i] - direct[k]) < 1e-12 for k in ['FAR', 'TPR'])
    passed('Resampled cutoff and rates match literal duplicated observations')
    groups = [dict(component_id='a'), dict(component_id='a'), dict(component_id='b')]
    weights = component_weights(groups, 50, np.random.default_rng(7))
    assert np.array_equal(weights[:, 0], weights[:, 1]) and np.all(weights[:, 0] + weights[:, 2] == 2)
    passed('Whole-component shared resampling')
    curve = selection_curve([.5, .5, .5, .5], [1, 0, 1, 0])
    assert abs(curve['AURC'] - .5) < 1e-12 and all(abs(r['accepted_EM'] - .5) < 1e-12 for r in curve['points'])
    assert answer_metrics('The Blue Boat', ['blue boat'])[0] == 1 and answer_metrics('no', ['yes'])[1] == 0
    passed('Expected random score ties, EM normalization, yes/no F1')
    x = np.array([[0, 2], [1, 2], [2, 2], [3, 2.]])
    head = fit_logistic(x, [0, 0, 1, 1], [0, 1])
    assert head['mean'] == [1.5, 2.] and np.all(np.diff(head_predict(head, x)) > 0)
    passed('Ridge logistic constant-feature stability and training-only normalization')
    from retrieval import build_bm25, bm25_search, fuse, top_indices
    docs = {'a': dict(title='', text='cat cat dog'), 'b': dict(title='', text='dog'), 'c': dict(title='', text='fish cat')}
    keys, index = build_bm25(docs, ['cat'], lambda *x: None)
    got, scores = bm25_search('cat cat', (keys, index), 3)
    independent = []
    for key in keys:
        words = docs[key]['text'].split()
        tf = words.count('cat')
        independent.append(math.log1p((3-2+.5)/(2+.5))*tf*2.5/(tf+1.5*(.25+.75*len(words)/2)) if tf else 0.)
    assert np.allclose(scores, np.array(independent)[got], atol=1e-15)
    assert list(top_indices([1, 1, 1], 2)) == [0, 1]
    assert fuse([2, 0, 1], [0, 2, 1], 3)[0] == [0, 2, 1]
    passed('BM25 formula, unique query terms and deterministic RRF ties')
    from collect_human_review import collect
    with tempfile.TemporaryDirectory(prefix='.selfcheck_', dir=BASE) as temporary:
        pending = collect(BASE / 'human_review', Path(temporary) / 'human.json')
        assert pending['status'] == 'pending' and pending['filled_a'] == pending['filled_b'] == 0
    passed('Blank human forms remain pending with no semantic gold')
    with np.load(BASE / 'data/diagnostic_training_features.npz') as training:
        for method in METHODS:
            indices = training[method]
            assert len(indices) == 32556
            assert training['labels'][indices].sum() == (13669 if method in ['NAT_RANDOM_CE', 'RET_CE'] else 16278)
        assert training['features'].shape == (65112, 8)
    passed('Exact original four-corner view counts and labels')
    groups = rows(BASE / 'data/groups.jsonl')
    identities = {}
    for g in groups:
        key = (g['cohort'], g['split'])
        identities.setdefault(key, set()).add(g['component_id'])
    sets = list(identities.values())
    assert all(not sets[i] & sets[j] for i in range(len(sets)) for j in range(i))
    passed('All four calibration/test cohort component sets disjoint')
    source = rows(BASE / 'data/source_records.jsonl')
    labels = [r['label'] for r in source]
    with np.load(BASE / 'data/old_predictions.npz') as predictions:
        for key, expected in read(BASE / 'data/source_cutoffs.json').items():
            assert abs(cutoff(predictions[key][-800:], labels)-expected) < 1e-12
    passed('All 13 original source calibration cutoffs independently reconstructed')
    if full_bm25:
        corpus = read(BASE / 'data/hot_corpus.json')
        keys, index = build_bm25(corpus, [g['question'] for g in groups], print)
        count = 0
        for g in groups:
            if g['cohort'] != 'v5_seen':
                continue
            indices, scores = bm25_search(g['question'], (keys, index))
            assert [keys[i] for i in indices[:40]] == g['retrieved_keys'][:40], 'Frozen BM25 mismatch ' + g['group_id']
            count += 1
        assert count == 1600
        passed('All 1600 frozen BM25 rankings reconstructed on complete 62838-doc corpus')
    print('CPU SELF CHECK PASS:', len(checks), '\n' + '\n'.join(checks))
    return checks


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--full-bm25', action='store_true')
    args = parser.parse_args()
    main(args.full_bm25)
