"""Reconstruct all unique four-corner global views from frozen text and keys.

Checks every original token hash. No need to trust the pre-rendered token stream.
Raw benchmark filtering is preserved as historical source, not rerun by this entry.
"""
import argparse
import hashlib
import sys
from common import *
from reproduce_training import safe_extract

BASE = Path(__file__).resolve().parent


def rebuild(output, original=None, write_tokens=False):
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    if original is None:
        extracted = output / 'frozen_source'
        original = extracted / 'paper4_06_formal_v5'
        if not (original / 'protocol.json').exists():
            safe_extract(BASE / 'reproduction/frozen_v5.tar.gz', extracted)
    sys.path.insert(0, str(BASE / 'legacy'))
    from core import messages
    from tasks import documents
    from transformers import AutoTokenizer
    tokenizer = AutoTokenizer.from_pretrained(BASE / 'qwen_tokenizer', local_files_only=True)
    plan = rows(original / 'plan.jsonl')
    metadata = {r['sample_id']: r for r in rows(original / 'record_metadata.jsonl')}
    groups = {g['group_id']: g for g in rows(original / 'groups.jsonl')}
    corpus = read(original / 'corpus.json')
    maps = rows(BASE / 'data/four_corner_training_maps.jsonl')
    indices = sorted({i for g in maps for rowids in g['global_rows_by_method'].values() for i in rowids})
    assert len(indices) == 65112
    result = []
    stream = (output / 'reconstructed_training_tokens.bin').open('wb') if write_tokens else None
    offset = 0
    try:
        for number, index in enumerate(indices, 1):
            row = plan[index]
            g = groups[row['group_id']]
            if row['sample_id'] in metadata:
                keys = metadata[row['sample_id']]['document_keys']
                docs = [corpus[k] for k in keys]
            else:
                docs = documents(g, corpus, row['condition'], row['label'])
                keys = [digest(d['title'].strip()+'\n'+d['text'].strip()) for d in docs]
            ids = tokenizer.apply_chat_template(messages(g['question'], docs), tokenize=True, add_generation_prompt=True)
            blob = np.asarray(ids, dtype='<i4').tobytes()
            assert hashlib.sha256(blob).hexdigest() == row['input_sha256'], 'Construction render mismatch '+row['sample_id']
            if stream:
                stream.write(blob)
            result.append(dict(original_row=index, sample_id=row['sample_id'], group_id=row['group_id'], question=g['question'], condition=row['condition'], label=row['label'],
                required=g['required'], document_keys=keys, reconstructed_offset=offset, tokens=len(ids), input_sha256=row['input_sha256']))
            offset += len(ids)
            if number % 5000 == 0:
                print('REBUILT_TRAINING_VIEWS', number, '/', len(indices), flush=True)
    finally:
        if stream:
            stream.close()
    lines(output / 'reconstructed_training_plan.jsonl', result)
    summary = dict(unique_global_views=len(indices), all_input_hashes_match=True, four_corner_maps_sha256=sha(BASE/'data/four_corner_training_maps.jsonl'),
        token_stream_written=write_tokens, total_tokens=offset, boundary='Reconstructs frozen selected question/document views; does not reselect raw benchmarks or claim independent GPU retraining')
    save(output / 'rebuild_summary.json', summary)
    return summary


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--write-tokens', action='store_true')
    a = p.parse_args()
    print(rebuild(a.output, write_tokens=a.write_tokens))
