SYSTEM = 'Judge whether the supplied evidence contains a complete evidence chain for answering the question. Use only the supplied text. Require the necessary entity identities and relations, and do not accept a possible answer or a partial relation as a complete chain. Reply Yes if complete; otherwise reply No.'

def messages(question, docs):
    text = '\n\n'.join((f"Document {i + 1}: {d['title']}\n{d['text']}" for i, d in enumerate(docs)))
    return [{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': f'Question: {question}\n\nEvidence:\n{text}'}]

def render(question, docs):
    return ''.join('<|im_start|>' + m['role'] + '\n' + m['content'] + '<|im_end|>\n' for m in messages(question, docs)) + '<|im_start|>assistant\n'
