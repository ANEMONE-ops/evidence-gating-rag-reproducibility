"""Public-label evaluation; no answer generation and no adapter training."""
import csv
from pathlib import Path
import numpy as np
from common import read, rows, save, cutoff, metrics, component_weights, boot_cutoffs, boot_rates, atomic_npz


def average_precision(labels, scores):
    """Noninterpolated precision-recall area, accepting complete score tie groups."""
    y, s = np.asarray(labels, dtype=bool), np.asarray(scores, dtype=float)
    if not y.any():
        return None
    order = np.argsort(-s, kind='stable')
    ends = np.r_[np.flatnonzero(np.diff(s[order])) + 1, len(s)]
    tp = np.cumsum(y[order])[ends - 1]
    recall, precision = tp / y.sum(), tp / ends
    return float(np.sum(np.diff(np.r_[0., recall]) * precision))


def write_csv(path, records):
    if not records:
        return
    with Path(path).open('w', encoding='utf-8-sig', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)


def paired_bootstrap(cal, test, predictions, fits, draws, rng, batch=100):
    """Same resampled components across fits; independently resampled cal/test."""
    ycal = np.array([r['label'] for r in cal])
    ytest = np.array([r['label'] for r in test])
    outputs = {key: [] for key in ('FAR', 'TPR')}
    for start in range(0, draws, batch):
        n = min(batch, draws - start)
        wc = component_weights(cal, n, rng)
        wt = component_weights(test, n, rng)
        per_method = {}
        for method in ('CE', 'NR'):
            accum = {key: np.zeros(n) for key in outputs}
            selected = [f for f in fits if f['method'] == method]
            assert len(selected) == 3
            for fit in selected:
                a, b = predictions[fit['key']]
                thresholds = boot_cutoffs(a, ycal, wc)
                rates = boot_rates(b, ytest, thresholds, wt)
                for key in outputs:
                    accum[key] += rates[key] / 3
            per_method[method] = accum
        for key in outputs:
            outputs[key].append(per_method['NR'][key] - per_method['CE'][key])
    return {key: np.concatenate(values) for key, values in outputs.items()}


def analyze(package, output):
    package, output = Path(package), Path(output)
    protocol = read(package / 'protocol.json')
    plan = rows(package / 'data/plan.jsonl')
    fits = protocol['fits']
    all_scores = {}
    for fit in fits:
        with np.load(output / 'cache' / (fit['key'] + '.npz'), allow_pickle=False) as data:
            assert data['done'].all() and np.isfinite(data['scores']).all()
            all_scores[fit['key']] = data['scores'].copy()
    per_fit, summary, contrasts, thresholds, boot_arrays = [], [], [], {}, {}
    rng = np.random.default_rng(protocol['statistics']['bootstrap_rng_seed'])
    for dataset in ('NoMIRACL', 'SQuAD2'):
        ci = [i for i, r in enumerate(plan) if r['dataset'] == dataset and r['role'] == 'calibration']
        ti = [i for i, r in enumerate(plan) if r['dataset'] == dataset and r['role'] == 'test']
        cal, test = [plan[i] for i in ci], [plan[i] for i in ti]
        yc, yt = [r['label'] for r in cal], [r['label'] for r in test]
        pairs = {key: (values[ci], values[ti]) for key, values in all_scores.items()}
        for fit in fits:
            key = fit['key']
            a, b = pairs[key]
            threshold = cutoff(a, yc, protocol['statistics']['calibration_tpr_target'])
            thresholds[dataset + ':' + key] = threshold
            value = metrics(yt, b, threshold)
            value['AUPRC_AP'] = average_precision(yt, b)
            per_fit.append(dict(dataset=dataset, method=fit['method'], run=fit['run'],
                fit_key=key, calibration_n=len(ci), calibration_TPR=metrics(yc, a, threshold)['TPR'], **value))
        for method in ('CE', 'NR', 'CH', 'NH'):
            selected = [r for r in per_fit if r['dataset'] == dataset and r['method'] == method]
            record = dict(dataset=dataset, method=method, fits=len(selected),
                test_n=len(ti), positive=sum(yt), negative=len(yt) - sum(yt))
            for metric in ('AUROC', 'AUPRC_AP', 'FAR', 'TPR', 'acceptance', 'Brier'):
                values = [r[metric] for r in selected]
                record[metric + '_mean'] = float(np.mean(values))
                record[metric + '_sd'] = float(np.std(values, ddof=1))
            summary.append(record)
        boot = paired_bootstrap(cal, test, pairs, fits,
            protocol['statistics']['bootstrap_draws'], rng)
        for metric, values in boot.items():
            boot_arrays[dataset + '_' + metric] = values
            nr = next(r for r in summary if r['dataset'] == dataset and r['method'] == 'NR')
            ce = next(r for r in summary if r['dataset'] == dataset and r['method'] == 'CE')
            bounds = np.quantile(values, [.025, .975, .00625, .99375])
            contrasts.append(dict(dataset=dataset, contrast='NR minus CE', endpoint=metric,
                difference=nr[metric + '_mean'] - ce[metric + '_mean'],
                CI95_low=float(bounds[0]), CI95_high=float(bounds[1]),
                CI98_75_low=float(bounds[2]), CI98_75_high=float(bounds[3]),
                units='proportion', bootstrap_draws=len(values),
                calibration_components=len({r['component_id'] for r in cal}),
                test_components=len({r['component_id'] for r in test})))
        print('ANALYSIS_FINISHED', dataset, flush=True)
    report = dict(status='complete', per_fit=per_fit, method_summary=summary,
        contrasts=contrasts, thresholds=thresholds, statistics=protocol['statistics'])
    save(output / 'metrics.json', report)
    write_csv(output / 'per_fit_metrics.csv', per_fit)
    write_csv(output / 'method_summary.csv', summary)
    write_csv(output / 'contrasts.csv', contrasts)
    atomic_npz(output / 'paired_bootstrap_draws.npz', **boot_arrays)
    def predictions():
        for i, rec in enumerate(plan):
            item = dict(rec)
            item['probabilities'] = {f['key']: float(all_scores[f['key']][i]) for f in fits}
            item['accepted'] = {f['key']: bool(all_scores[f['key']][i] >=
                thresholds[rec['dataset'] + ':' + f['key']]) for f in fits}
            yield item
    from common import lines
    lines(output / 'predictions.jsonl', predictions())
    return report
