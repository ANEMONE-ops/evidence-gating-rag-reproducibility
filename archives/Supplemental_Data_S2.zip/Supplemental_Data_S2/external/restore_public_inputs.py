"""Rebuild all original public inputs by source ID; optionally verify every token hash."""
from collections import defaultdict
from pathlib import Path
import argparse
import csv
import gzip
import hashlib
import json
import sys
import urllib.request
import numpy as np
from reproduce_external import inputs

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'code'))
from prompt import render


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def rebuild(raw_root, output, tokenizer_file=None, download=False):
    manifest = json.loads((HERE / 'raw_manifest.json').read_text(encoding='utf-8'))
    for relative, expected in manifest.items():
        path = raw_root / relative
        if not path.exists() and download:
            path.parent.mkdir(parents=True, exist_ok=True)
            urllib.request.urlretrieve(expected['url'], path)
        assert path.is_file(), 'Missing source: ' + str(path)
        assert hashlib.sha256(path.read_bytes()).hexdigest() == expected['sha256'], relative
    with gzip.open(raw_root / 'NoMIRACL_english/corpus.jsonl.gz', 'rt', encoding='utf-8') as stream:
        raw_corpus = {}
        for doc in map(json.loads, stream):
            key = doc['docid']
            assert key not in raw_corpus or raw_corpus[key] == doc
            raw_corpus[key] = doc
    corpus = {'N:' + key: dict(title=doc['title'], text=doc['text'], text_sha256=digest(doc['text']))
        for key, doc in raw_corpus.items()}
    nomiracl = {}
    for split in ('dev', 'test'):
        for subset in ('relevant', 'non_relevant'):
            topics = dict(csv.reader((raw_root / f'NoMIRACL_english/topics/{split}.{subset}.tsv').open(encoding='utf-8'), delimiter='\t'))
            qrels = defaultdict(dict)
            for qid, _, did, value in csv.reader((raw_root / f'NoMIRACL_english/qrels/{split}.{subset}.tsv').open(encoding='utf-8'), delimiter='\t'):
                if qid in topics:
                    qrels[qid][did] = int(value)
            for qid, question in topics.items():
                keys = ['N:' + did for did in qrels[qid]]
                keys.sort(key=lambda key: digest('nomiracl-order-v1:' + qid + ':' + key))
                nomiracl[(split, qid)] = question, keys, int(any(qrels[qid].values())), subset
    squad = {}
    for split in ('train', 'dev'):
        data = json.loads((raw_root / f'SQuAD2/{split}-v2.0.json').read_text(encoding='utf-8'))
        for article in data['data']:
            for paragraph in article['paragraphs']:
                key = 'S:' + digest(article['title'] + '\n' + paragraph['context'])
                corpus[key] = dict(title='', source_title=article['title'], text=paragraph['context'], text_sha256=digest(paragraph['context']))
                for qa in paragraph['qas']:
                    squad[(split, qa['id'])] = qa['question'], key, int(not qa['is_impossible']), article['title']
    tokenizer = None
    if tokenizer_file:
        from tokenizers import Tokenizer
        tokenizer = Tokenizer.from_file(str(tokenizer_file))
    plan, used, offset = [], set(), 0
    output.mkdir(parents=True, exist_ok=True)
    token_stream = (output / 'token_ids.bin').open('wb') if tokenizer else None
    try:
        for rec in inputs():
            dataset, split, qid = rec['dataset'], rec['official_split'], rec['official_id']
            record = {key: rec[key] for key in ('sample_id', 'dataset', 'role', 'official_split')}
            if dataset == 'NoMIRACL':
                question, keys, label, subset = nomiracl[(split, qid)]
                record.update(official_subset=subset, official_id=qid)
            else:
                question, key, label, title = squad[(split, qid)]
                keys = [key]
                record.update(official_id=qid, article=title)
            assert label == rec['label']
            record.update(question=question, label=label, document_keys=keys, component_id=rec['component_id'],
                offset=offset, tokens=rec['tokens'], input_sha256=rec['input_sha256'], document_count=len(keys))
            if tokenizer:
                ids = tokenizer.encode(render(question, [corpus[key] for key in keys]), add_special_tokens=False).ids
                raw_ids = np.array(ids, dtype='<i4').tobytes()
                assert len(ids) == rec['tokens'] and hashlib.sha256(raw_ids).hexdigest() == rec['input_sha256']
                token_stream.write(raw_ids)
            offset += rec['tokens']
            used.update(keys)
            plan.append(record)
    finally:
        if token_stream:
            token_stream.close()
    with (output / 'plan.jsonl').open('w', encoding='utf-8', newline='\n') as stream:
        for rec in plan:
            stream.write(json.dumps(rec, ensure_ascii=False, separators=(',', ':')) + '\n')
    provenance = json.loads((HERE / 'compact_storage.json').read_text(encoding='utf-8'))
    assert hashlib.sha256((output / 'plan.jsonl').read_bytes()).hexdigest() == provenance['original_plan_sha256']
    with gzip.open(output / 'corpus.jsonl.gz', 'wt', encoding='utf-8', newline='\n') as stream:
        for key in sorted(used):
            stream.write(json.dumps(dict(document_key=key, **corpus[key]), ensure_ascii=False) + '\n')
    if tokenizer:
        assert hashlib.sha256((output / 'token_ids.bin').read_bytes()).hexdigest() == provenance['original_token_binary_sha256']
    print('PUBLIC_INPUT_RECONSTRUCTION_PASS', len(plan), 'token_checks', bool(tokenizer), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--raw-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=HERE / 'reconstructed_inputs')
    parser.add_argument('--tokenizer-file', type=Path)
    parser.add_argument('--download', action='store_true', help='Download missing originals from frozen official URLs')
    args = parser.parse_args()
    rebuild(args.raw_root.resolve(), args.output.resolve(), args.tokenizer_file, args.download)
