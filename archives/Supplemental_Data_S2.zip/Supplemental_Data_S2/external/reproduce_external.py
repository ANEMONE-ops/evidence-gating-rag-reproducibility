"""Recompute every external metric and all 5000 paired draws from lossless scores."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'code'))
from common import read, rows, lines, atomic_npz, save
from analyze import analyze


def inputs():
    with np.load(HERE / 'inputs.npz', allow_pickle=False) as stored:
        records = []
        for i in range(len(stored['label'])):
            dataset = 'NoMIRACL' if stored['dataset'][i] == 0 else 'SQuAD2'
            role = 'calibration' if stored['role'][i] == 0 else 'test'
            original_id = stored['official_id'][i].decode('ascii')
            split = ('dev' if role == 'calibration' else 'test') if dataset == 'NoMIRACL' else (
                'train' if role == 'calibration' else 'dev')
            label = int(stored['label'][i])
            subset = 'relevant' if label else 'non_relevant'
            sample = f'{dataset}:{split}:' + (subset + ':' if dataset == 'NoMIRACL' else '') + original_id
            records.append(dict(sample_id=sample, dataset=dataset, role=role, official_split=split,
                official_id=original_id, label=label, component_id=stored['component_id'][i].decode('ascii'),
                tokens=int(stored['tokens'][i]), input_sha256=stored['input_sha256'][i].decode('ascii')))
    return records


if __name__ == '__main__':
    records = inputs()
    assert len(records) == 16839
    output = HERE / 'recomputed'
    source = output / 'inputs'
    (source / 'data').mkdir(parents=True, exist_ok=True)
    lines(source / 'data/plan.jsonl', records)
    save(source / 'protocol.json', read(HERE / 'protocol.json'))
    with np.load(HERE / 'scores.npz', allow_pickle=False) as scores:
        assert len(scores.files) == 12
        for key in scores.files:
            values = scores[key].astype(np.float64)
            assert len(values) == len(records) and np.isfinite(values).all()
            atomic_npz(output / 'cache' / (key + '.npz'), scores=values, done=np.ones(len(values), dtype=bool))
    report = analyze(source, output)
    original = read(HERE / 'reported/metrics.json')
    def compare(a, b):
        if isinstance(a, dict):
            assert set(a) == set(b)
            for key in a:
                compare(a[key], b[key])
        elif isinstance(a, list):
            assert len(a) == len(b)
            for left, right in zip(a, b):
                compare(left, right)
        elif isinstance(a, float):
            assert abs(a - b) < 1e-12
        else:
            assert a == b
    compare(report, original)
    with np.load(output / 'paired_bootstrap_draws.npz', allow_pickle=False) as a, np.load(
            HERE / 'reported/paired_bootstrap_draws.npz', allow_pickle=False) as b:
        assert set(a.files) == set(b.files)
        assert all(np.allclose(a[key], b[key], rtol=0, atol=1e-12) for key in a.files)
    save(output / 'reproduction_check.json', dict(status='passed', probabilities=202068,
        input_rows=16839, metrics_per_fit=24, planned_contrasts=4, draws_per_contrast=5000))
    print('EXTERNAL_NUMERICAL_REPRODUCTION_PASS', flush=True)
