# Supplemental Data S4

Figure export records for the current eleven-figure manuscript.

- `Figures1-3/` contains the editable PowerPoint artwork and the export record for the three images. The reading copy retains the full-resolution exports. The standalone submission PNGs for Figures 1–3 preserve their composition at 3000 × 2000 px.
- `Figure3/HotpotQA_Dialogue_Case.json` records the evaluated question, raw reader answers, reference answer, and support ranks used to construct the dialogue. It identifies the archived records in Supplemental Data S2.
- `Retrieval_Coverage/` preserves all eight measured coverage observations and the script for the preceding allocation and coverage plot. Run `python reproduce_Figure3.py` in that folder to reproduce that historical analytical layout.
- `Figure6/` reproduces the three-run ROC plot from all 7,536 recorded probabilities. Install its requirements, then run `python reproduce_Figure6.py` in that folder. Displayed panels use Run 1, Run 2, and Run 3.

Figures 1 and 2 are conceptual schematics with illustrative passage cards. Figure 3 presents one documented HotpotQA case in dialogue form. Figures 4–11 are analytical plots prepared with Python, Matplotlib, and NumPy. Historical plot labels in Supplemental Data S3 use the preceding numbering: original Figures 5–11 correspond to current Figures 4–10.

## Figure 11 public-label validation

Figure 11 is a Python/Matplotlib forest plot using all four frozen external NR-minus-CE contrasts. Source values are unrounded server outputs, independently recomputed from all saved scores. Units are percentage points. Thick intervals are 95%; thin intervals are Bonferroni-adjusted 98.75% for a four-endpoint family. Run `python reproduce_Figure11.py`; outputs appear in reproduced/. Both panels use the same dataset order and aligned plot boxes. PDF/SVG are vector outputs; PNG is a 450-dpi preview. Minimum plotted text is 7.6 pt. Alignment and collision checks passed. Optional generic Nature-size/TIFF/600-dpi recommendations are not requirements for this vector-PDF PeerJ submission. Source-data hashes appear in the S4 manifest.
