"""Plot frozen component counts and all eight measured coverage observations."""
from pathlib import Path
import csv, json, sys
import os
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parent/'plot_cache'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

from audit_panel_alignment import require_matplotlib_panel_alignment

Q=Path(__file__).resolve().parent
F=Q.parent
OUT=Q/'reproduced_Figure3'
for p in [OUT/'PNG',OUT/'SVG',Q/'figure_qa']:p.mkdir(parents=True,exist_ok=True)
source=Q/'Figure3_SourceData.csv'
rows=[r for r in csv.DictReader(source.open(encoding='utf-8-sig')) if r['cohort']=='v6_unseen' and r['split']=='test']
assert len(rows)==8
for r in rows:assert int(r['positive'])+int(r['negative'])==628
with (Q/'Figure3_SourceData.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
plt.rcParams.update({'font.family':'Arial','font.size':8,'axes.labelsize':8,'xtick.labelsize':7.6,'ytick.labelsize':7.6,'legend.fontsize':7.6,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'svg.fonttype':'none'})
fig=plt.figure(figsize=(6.5,3.2),facecolor='white')
left=fig.add_axes([.015,.16,.43,.74]);right=fig.add_axes([.575,.16,.405,.74])
for ax,title in [(left,'a  Independent source components'),(right,'b  Retrieved support coverage')]:
    ax.set_title(title,fontsize=8.5,fontweight='bold',loc='left',pad=12)
left.set_xlim(0,1);left.set_ylim(0,1);left.axis('off')
def box(cx,cy,w,h,text,fill):
    left.add_patch(FancyBboxPatch((cx-w/2,cy-h/2),w,h,boxstyle='round,pad=0.012,rounding_size=0.018',edgecolor='#B7C9D6',facecolor=fill,lw=.75))
    left.text(cx,cy,text,ha='center',va='center',fontsize=7.4,color='#263C4D',linespacing=1.2)
def arrow(start,end):left.annotate('',xy=end,xytext=start,arrowprops={'arrowstyle':'-|>','color':'#748898','lw':.8,'shrinkA':3,'shrinkB':3})
box(.5,.88,.94,.19,'Clean pool\n2,528 questions / 2,325 components','#ECF4F9')
box(.5,.54,.94,.22,'Historical allocation: 1,600 questions\nUnscored remainder: 928 questions','#F3F5F7')
arrow((.5,.78),(.5,.67))
box(.245,.14,.44,.23,'Calibration\n300 questions\n276 components','#FCF1E6')
box(.755,.14,.44,.23,'Test\n628 questions\n590 components','#EAF6F3')
arrow((.36,.42),(.245,.25));arrow((.64,.42),(.755,.25))
colors={'BM25':'#63758A','HYBRID_RRF':'#2176A5'}
for key,marker,label in [('BM25','o','BM25'),('HYBRID_RRF','s','HYBRID')]:
    series=sorted([r for r in rows if r['retriever']==key],key=lambda r:int(r['paragraphs']))
    x=np.array([int(r['paragraphs']) for r in series]);y=np.array([int(r['positive'])/628*100 for r in series])
    assert len(x)==4 and list(x)==[12,20,32,40]
    right.plot(x,y,lw=1.5,marker=marker,markersize=4,color=colors[key],label=label)
    for xx,yy in zip(x,y):
        below=key=='BM25' and xx==40
        right.annotate(f'{yy:.2f}',(xx,yy),xytext=(0,-7 if below else 6),textcoords='offset points',ha='center',va='top' if below else 'baseline',fontsize=6.8,color=colors[key])
right.set_xlim(10,42);right.set_ylim(60,93)
right.set_xticks([12,20,32,40]);right.set_yticks([60,70,80,90])
right.set_xlabel('Retrieved paragraphs');right.set_ylabel('Complete-support coverage (%)')
right.grid(axis='y',color='#E9EDF0',lw=.65);right.set_axisbelow(True)
right.legend(loc='lower right',frameon=False,handlelength=2)
fig.canvas.draw()
require_matplotlib_panel_alignment(fig,axes=[left,right],panel_ids=['a','b'],row_groups=[['a','b']],column_groups=[],json_out=Q/'figure_qa/Figure3_alignment.json',overlay_svg=Q/'figure_qa/Figure3_alignment.svg',tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
fig.savefig(OUT/'Figure3.pdf',bbox_inches='tight',pad_inches=.045)
fig.savefig(OUT/'SVG/Figure3.svg',bbox_inches='tight',pad_inches=.045)
fig.savefig(OUT/'PNG/Figure3.png',dpi=450,bbox_inches='tight',pad_inches=.045)
plt.close(fig)
print('Exported Figure 3 from eight frozen coverage observations; no interpolation or smoothing.')
