"""Reproduce Figure 6 from every recorded test probability.

Only the displayed training-run identifiers differ from the preceding figure.
"""
from pathlib import Path
from collections import defaultdict
import csv, os, json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.transforms import Bbox
from PIL import Image
from audit_panel_alignment import require_matplotlib_panel_alignment

HERE = Path(__file__).resolve().parent
OUT = HERE / 'figures'; QA = HERE / 'figure_audits'
for p in [OUT, OUT/'PNG', OUT/'SVG', QA]: p.mkdir(exist_ok=True, parents=True)
plt.rcParams.update({'font.family':'Arial','font.size':8.4,'axes.labelsize':8.3,'axes.titlesize':9.2,
 'xtick.labelsize':7.7,'ytick.labelsize':7.7,'legend.fontsize':7.7,'axes.linewidth':.7,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white','figure.facecolor':'white'})
COL={'CE':'#63758A','NR':'#2176A5','CH':'#BE8057','NH':'#8772AF'}
INK='#263C4D';GRAY='#697D8C'
def base(height):
    f=plt.figure(figsize=(8.5,11));f._height=height
    return f
def axis(f,x,y,w,h):
    # Coordinates in the 6.5 inch artwork region, origin at its upper left.
    return f.add_axes([(1+x)/8.5,(10-y-h)/11,w/8.5,h/11])
def panel(ax,letter,title):
    ax.set_title(letter+'  '+title,loc='left',fontweight='bold',pad=12,color=INK)
def clean(ax):
    ax.spines[['top','right']].set_visible(False);ax.tick_params(length=3,width=.7,color=GRAY)
    ax.set_axisbelow(True);ax.grid(axis='y',color='#E9EDF0',lw=.65)
def save(f,n,axes=None):
    f.canvas.draw()
    if axes:
        row_groups=defaultdict(list);column_groups=defaultdict(list)
        for j,ax in enumerate(axes):
            bb=ax.get_position();row_groups[round(bb.y0,5)].append(chr(97+j));column_groups[round(bb.x0,5)].append(chr(97+j))
        require_matplotlib_panel_alignment(f,axes=axes,panel_ids=[chr(97+j) for j in range(len(axes))],row_groups=[v for v in row_groups.values() if len(v)>1],column_groups=[v for v in column_groups.values() if len(v)>1],json_out=QA/f'Figure{n}_alignment.json',overlay_svg=QA/f'Figure{n}_alignment.svg',tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
    else:
        (QA/f'Figure{n}_alignment.json').write_text(json.dumps({'status':'NOT APPLICABLE','reason':'Single axes with intentionally unequal schematic regions.'}),encoding='utf-8')
    f.savefig(OUT/f'Figure{n}.pdf')
    crop=Bbox.from_bounds(1,10-f._height,6.5,f._height)
    f.savefig(OUT/'SVG'/f'Figure{n}.svg',bbox_inches=crop)
    raster_dpi=3000/max(6.5,f._height)
    f.savefig(OUT/'PNG'/f'Figure{n}.png',bbox_inches=crop,dpi=raster_dpi)
    with Image.open(OUT/'PNG'/f'Figure{n}.png') as im:
        im=im.convert('RGB');assert min(im.size)>=900 and max(im.size)<=3000,im.size
        im.save(OUT/'PNG'/f'Figure{n}.png',dpi=(raster_dpi,raster_dpi))
        im.thumbnail((1500,1700));im.save(QA/f'Figure{n}_preview.png')
    plt.close(f)


rows = list(csv.DictReader((HERE/'source_data/primary_test_scores.csv').open(encoding='utf-8')))
fit_ids = sorted({int(r['seed']) for r in rows})
assert len(rows) == 4 * 3 * 628 and len(fit_ids) == 3
reference = [r for r in rows if r['recipe']=='CE' and int(r['seed'])==fit_ids[0]]
y = np.array([int(r['label']) for r in reference])
ids = [r['sample_id'] for r in reference]
assert len(y)==628 and int(y.sum())==548
scores={}
for method in COL:
    for fit in fit_ids:
        rr=[r for r in rows if r['recipe']==method and int(r['seed'])==fit]
        assert [r['sample_id'] for r in rr] == ids
        assert np.array_equal(y, [int(r['label']) for r in rr])
        scores[method,fit] = np.array([float(r['probability']) for r in rr])
        assert np.isfinite(scores[method,fit]).all()

def roc(labels,prob):
    order=np.argsort(-prob,kind='stable');p=prob[order];truth=labels[order]
    ends=np.r_[np.where(np.diff(p)!=0)[0],len(p)-1]
    tp=np.cumsum(truth)[ends];fp=(ends+1)-tp
    return np.r_[0,fp/(len(truth)-sum(truth))],np.r_[0,tp/sum(truth)]

f=base(3.4);axs=[axis(f,.48+i*2.15,.4,1.55,2.1) for i in range(3)]
for run_number,(ax,fit,letter) in enumerate(zip(axs,fit_ids,'abc'),1):
    panel(ax,letter,f'Run {run_number}')
    for method in COL:
        xx,yy=roc(y,scores[method,fit]);ax.step(xx,yy,where='post',color=COL[method],lw=1.3,label=method)
    ax.plot([0,1],[0,1],color='#AAB5BD',lw=.8,ls='--')
    ax.set(xlim=(0,1),ylim=(0,1.02),xticks=[0,.5,1],yticks=[0,.5,1],xlabel='False positive rate')
    clean(ax)
axs[0].set_ylabel('True positive rate')
f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=4,frameon=False,bbox_to_anchor=(.5,(10-2.9)/11))
save(f,6,axs)
print('Figure 6: all 7,536 probabilities retained; three matched runs displayed.')
