"""Plot all frozen external contrasts; every interval is independently audited."""
from pathlib import Path
import csv
import json
import shutil
import sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from audit_panel_alignment import require_matplotlib_panel_alignment

HERE = Path(__file__).resolve().parent
OUT = HERE / 'reproduced'
OUT.mkdir(exist_ok=True)
source = HERE / 'source_data.csv'
shutil.copyfile(source, OUT / 'source_data.csv')
records = list(csv.DictReader(source.open(encoding='utf-8-sig', newline='')))
assert len(records) == 4
plt.rcParams.update({'font.family': 'Arial', 'font.size': 8.3, 'axes.labelsize': 8.2,
    'xtick.labelsize': 8, 'ytick.labelsize': 8.4, 'axes.linewidth': .7,
    'pdf.fonttype': 42, 'ps.fonttype': 42, 'svg.fonttype': 'none'})
fig, axes = plt.subplots(1, 2, figsize=(6.5, 2.7), gridspec_kw={'width_ratios': [1, 1]})
fig.subplots_adjust(left=.15, right=.97, top=.79, bottom=.32, wspace=.45)
for ax, metric, letter, title in zip(axes, ['FAR', 'TPR'], 'ab', ['False acceptance', 'Positive retention']):
    for y, dataset in [(1, 'NoMIRACL'), (0, 'SQuAD2')]:
        r = next(r for r in records if r['dataset'] == dataset and r['endpoint'] == metric)
        point = 100 * float(r['difference'])
        outer = [100 * float(r[k]) for k in ['CI98_75_low', 'CI98_75_high']]
        inner = [100 * float(r[k]) for k in ['CI95_low', 'CI95_high']]
        ax.plot(outer, [y, y], color='#2176A5', linewidth=1.15, solid_capstyle='butt')
        ax.plot(inner, [y, y], color='#2176A5', linewidth=3.6, solid_capstyle='butt')
        ax.scatter([point], [y], s=33, marker='s', color='#2176A5', edgecolor='white', linewidth=.6, zorder=4)
    ax.axvline(0, color='#A4ADB5', linewidth=.8, linestyle='--', zorder=0)
    ax.set_title(letter + '  ' + title, loc='left', pad=15, fontsize=9.2, fontweight='bold', color='#263C4D')
    ax.set(ylim=(-.6, 1.6), yticks=[0, 1], yticklabels=['SQuAD 2.0', 'NoMIRACL'],
        xlabel='NR − CE (percentage points)')
    ax.spines[['top', 'right', 'left']].set_visible(False)
    ax.tick_params(axis='y', length=0, pad=5)
    ax.tick_params(axis='x', length=3, color='#63758A')
axes[0].set(xlim=(-12, 12), xticks=[-10, -5, 0, 5, 10])
axes[1].set(xlim=(-5, 12), xticks=[-5, 0, 5, 10])
fig.text(.5, .085, 'Thick intervals: 95%     Thin intervals: adjusted 98.75%', ha='center', fontsize=7.6, color='#526575')
fig.canvas.draw()
require_matplotlib_panel_alignment(fig, axes=list(axes), panel_ids=['a', 'b'],
    row_groups=[['a', 'b']], json_out=OUT / 'alignment.json',
    overlay_svg=OUT / 'alignment.svg', tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True)
fig.savefig(OUT / 'Figure11.pdf')
fig.savefig(OUT / 'Figure11.svg')
fig.savefig(OUT / 'Figure11.png', dpi=450)
plt.close(fig)
print('Figure11 exported')
