"""Recompute the historical controlled-context AUROC comparison from raw scores."""
from pathlib import Path
import csv,json
import numpy as np
HERE=Path(__file__).resolve().parent
rows=[json.loads(s) for s in (HERE/'historical/record_index.jsonl').read_text(encoding='utf-8').splitlines()]
maps={'CE':'CE','NR':'NAT_RANDOM_CE','CH':'CORE_HARD_CE','NH':'RET_CE'}
def auroc(y,s):
    order=np.argsort(s,kind='stable');v=s[order];ranks=np.empty(len(s),float)
    cuts=np.r_[0,np.flatnonzero(np.diff(v))+1,len(v)]
    for a,b in zip(cuts[:-1],cuts[1:]):ranks[order[a:b]]=(a+b+1)/2
    p=int(y.sum());n=len(y)-p
    return float((ranks[y==1].sum()-p*(p+1)/2)/(p*n))
results=[]
for dataset,questions in [('MuSiQue',356),('HotpotQA',800),('IIRC',500)]:
    idx=[i for i,r in enumerate(rows) if r['dataset']==dataset and r['split']=='test' and r['family']=='controlled' and r['condition']=='n40' and r['task']=='global']
    assert len(idx)==2*questions
    y=np.array([rows[i]['label'] for i in idx]);assert y.sum()==questions
    for method,key in maps.items():
        values=[]
        for seed in [11,29,47]:
            z=np.load(HERE/f'historical/prediction_cache/{key}_seed{seed}.npz')
            assert len(z['probability'])==len(rows) and z['done'][idx].all()
            values.append(auroc(y,z['probability'][idx]))
        results.append(dict(dataset=dataset,method=method,AUROC_mean=float(np.mean(values)),AUROC_seed_SD=float(np.std(values,ddof=1))))
reported=list(csv.DictReader((HERE/'figure_sources/source_data/historical_controlled_auroc.csv').open(encoding='utf-8-sig')))
for a,b in zip(results,reported):
    assert a['dataset']==b['dataset'] and a['method']==b['method']
    for col in ['AUROC_mean','AUROC_seed_SD']:assert f"{a[col]:.4f}"==f"{float(b[col]):.4f}",(a,b)
out=HERE/'historical/recomputed_controlled_auroc.csv'
with out.open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(results[0]));w.writeheader();w.writerows(results)
print('All twelve historical dataset-by-construction means and SDs reproduce to their reported precision.')
