"""Operational annotated-evidence coverage task and label-free selectors."""
import math
import re
from collections import Counter
import numpy as np
from frozen_core import digest,save,jsonlines,metrics,threshold,sigmoid,fit_head

COMMIT='989aa7980e4cf806f80c7fef2b1adb7bc71aa306'
SYSTEM=('Judge whether the supplied evidence contains a complete evidence chain for answering the question. '
        'Use only the supplied text. Require the necessary entity identities and relations, and do not '
        'accept a possible answer or a partial relation as a complete chain. Reply Yes if complete; otherwise reply No.')
VIEWS=['full','bm25_8','titlegraph_8']
LOSSES={'lora_CE':(0.,0.),'lora_CE_rank':(.2,0.),'lora_CE_inv':(0.,1.),'lora_CE_rank_inv':(.2,1.)}


def terms(s):return re.findall(r'[a-z0-9]+',s.casefold())
def norm(s):return ' '.join(s.casefold().split())
def doc_key(d):return digest(d['title'].strip()+'\n'+d['text'].strip())


def rank_documents(question,docs,graph_weight=0.):
    # Deduplication and stable tie-breaking are shared by both selectors.
    unique={doc_key(d):d for d in docs};keys=sorted(unique);docs=[unique[k] for k in keys]
    counts=[Counter(terms(d['title']+' '+d['text'])) for d in docs]
    lengths=np.array([sum(c.values()) for c in counts],dtype=float);avg=max(float(lengths.mean()),1.)
    query=sorted(set(terms(question)));n=len(docs);df={t:sum(t in c for c in counts) for t in query}
    bm=np.array([sum(math.log(1+(n-df[t]+.5)/(df[t]+.5))*c[t]*2.5/(c[t]+1.5*(.25+.75*l/avg))
                     for t in query if c[t]) for c,l in zip(counts,lengths)])
    if graph_weight:
        seed=bm+1e-8;seed=seed/seed.sum();adj=np.zeros((n,n),dtype=float)
        texts=[' '+' '.join(terms(d['text']))+' ' for d in docs]
        titles=[' '.join(terms(re.sub(r'\([^)]*\)','',d['title']))) for d in docs]
        for i in range(n):
            for j in range(n):
                if i!=j and len(titles[j])>=5 and ' '+titles[j]+' ' in texts[i]:adj[i,j]=1.
        adj=adj+adj.T
        sums=adj.sum(1);transition=adj/np.maximum(sums[:,None],1.)
        p=seed.copy()
        for _ in range(12):
            dangling=float(p[sums==0].sum());p=.35*seed+.65*(transition.T@p+dangling*seed)
        score=(1-graph_weight)*(bm/max(float(bm.sum()),1e-8))+graph_weight*p
    else:score=bm
    return [docs[i] for i in sorted(range(n),key=lambda i:(-round(float(score[i]),12),keys[i]))]


def select(question,docs,view,graph_weight=.5):
    if view=='full':return docs
    return rank_documents(question,docs,graph_weight if view=='titlegraph_8' else 0.)[:8]


def context(group,corpus,condition,label):
    required=group['required'];noise=group['noise'];missing=group['missing']
    base=list(required)+noise[:12-len(required)]
    base=[key for i,key in sorted(enumerate(base),key=lambda pair:digest(group['group_id']+':order:'+str(pair[0])))]
    replacement=group['replacement']
    if condition in ['dup4','shuffle']:count=12
    else:count=int(condition[1:])
    assert count>=12
    extra=noise[12-len(required):count-len(required)]
    for j,key in enumerate(extra):
        position=int(digest(group['group_id']+':extra:'+str(j))[:8],16)%(len(base)+1)
        base.insert(position,key)
    if not label:base=[replacement if key==missing else key for key in base]
    if condition=='dup4':base=base+base[:4]
    if condition=='shuffle':base=base[::-1]
    present=set(base);complete=set(required)<=present
    assert complete==bool(label),'Operational label violated'
    assert len(base)==(16 if condition=='dup4' else count)
    return [corpus[k] for k in base]


def conditions(group):
    if group['split'] in ['train','dev']:return ['n12','n20']
    if group['split']=='calibration':return ['n12']
    return ['n12','n20','n32','n40']+(['dup4','shuffle'] if group.get('robustness') else [])


def messages(question,docs):
    text='\n\n'.join(f"Document {i+1}: {d['title']}\n{d['text']}" for i,d in enumerate(docs))
    return [{'role':'system','content':SYSTEM},{'role':'user','content':f'Question: {question}\n\nEvidence:\n{text}'}]


def samples(groups,corpus,graph_weight):
    for group in groups:
        for condition in conditions(group):
            for label in [0,1]:
                docs=context(group,corpus,condition,label)
                for view in VIEWS:
                    chosen=select(group['question'],docs,view,graph_weight)
                    meta={'sample_id':group['group_id']+':'+condition+':'+str(label)+':'+view,
                        'group_id':group['group_id'],'dataset':group['dataset'],'split':group['split'],
                        'condition':condition,'label':label,'view':view,'document_count':len(chosen),
                        'characters':sum(len(d['text'])+len(d['title']) for d in chosen)}
                    yield meta,messages(group['question'],chosen)


def self_check():
    corpus={}
    for i in range(50):
        d={'title':f'Entity {i}','text':f'Entity {i} has value {i}.'};corpus[doc_key(d)]=d
    keys=list(corpus);group={'group_id':'toy','required':keys[:3],'missing':keys[1],
        'noise':keys[3:43],'replacement':keys[45],'question':'What value does Entity 0 have?','split':'train','dataset':'toy'}
    for c in ['n12','n20','n32','n40','dup4','shuffle']:
        for label in [0,1]:
            docs=context(group,corpus,c,label)
            assert set(group['required'])<={doc_key(d) for d in docs} if label else group['missing'] not in {doc_key(d) for d in docs}
            for v in ['bm25_8','titlegraph_8']:
                assert select(group['question'],docs,v)==select(group['question'],docs[::-1]+docs[:2],v)
    print('PASS: known coverage labels, balanced document counts, duplicate/permutation-invariant selectors.')


if __name__=='__main__':self_check()
