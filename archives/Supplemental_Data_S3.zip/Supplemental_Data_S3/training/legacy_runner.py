"""Single resumable formal batch: frozen baselines, LoRA factorial, sealed evaluation."""
import os
for key,value in {'OMP_NUM_THREADS':'8','OPENBLAS_NUM_THREADS':'8','MKL_THREADING_LAYER':'SEQUENTIAL',
                  'HF_ENDPOINT':'https://hf-mirror.com','HF_HUB_ETAG_TIMEOUT':'30','HF_HUB_DOWNLOAD_TIMEOUT':'120'}.items():
    os.environ.setdefault(key,value)
import argparse
from datetime import datetime,timezone
import hashlib,json,math,shutil,subprocess,sys,time,traceback
from pathlib import Path
import numpy as np
from core import *

BASE=Path(__file__).resolve().parent


def validate():
    protocol=json.loads((BASE/'protocol.json').read_text(encoding='utf-8'))
    for name,expected in protocol['files_sha256'].items():
        assert hashlib.sha256((BASE/name).read_bytes()).hexdigest()==expected,'Changed input: '+name
    groups=jsonlines(BASE/'groups.jsonl');plan=jsonlines(BASE/'plan.jsonl')
    assert len({g['group_id'] for g in groups})==len(groups)
    assert len({r['sample_id'] for r in plan})==len(plan)
    assert all(r['tokens']<=8192 and r['label'] in [0,1] for r in plan)
    assert sum(g['split']=='train' for g in groups)==2000
    assert protocol['epochs']==1 and protocol['selection_checkpoints']==[.5,1.]
    assert not any(g['dataset']!='MuSiQue' and g['split']!='test' for g in groups)
    offset=0
    for r in plan:assert r['offset']==offset;offset+=r['tokens']
    assert (BASE/'token_ids.bin').stat().st_size==offset*4
    return protocol,groups,plan


def token_array(plan):return np.memmap(BASE/'token_ids.bin',mode='r',dtype='<i4')


def load_model():
    import torch
    from transformers import AutoModelForCausalLM,AutoTokenizer
    assert torch.cuda.is_available(),'Run on the verified GPU server'
    assert torch.__version__.startswith('2.1.2'),'Expected verified server torch2.1.2'
    import importlib.metadata as metadata
    assert metadata.version('transformers')=='4.45.2'
    torch.set_num_threads(8);torch.manual_seed(20261025)
    tokenizer=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision=COMMIT,trust_remote_code=False)
    assert [tokenizer.encode(s,add_special_tokens=False) for s in ['No','Yes']]==[[2753],[9454]]
    model,info=AutoModelForCausalLM.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision=COMMIT,
        trust_remote_code=False,torch_dtype=torch.bfloat16,attn_implementation='sdpa',
        low_cpu_mem_usage=False,use_safetensors=True,output_loading_info=True)
    assert model.config._commit_hash==COMMIT
    assert not any(info.get(k) for k in ['missing_keys','unexpected_keys','mismatched_keys','error_msgs'])
    model.requires_grad_(False);model.eval().to('cuda:0');model.config.use_cache=False
    return model,tokenizer,info


def input_tensor(tokens,row,device='cuda:0'):
    import torch
    ids=np.array(tokens[row['offset']:row['offset']+row['tokens']],dtype=np.int64,copy=True)
    assert hashlib.sha256(ids.astype('<i4').tobytes()).hexdigest()==row['input_sha256']
    return torch.from_numpy(ids).unsqueeze(0).to(device)


def cache_features(model,tokens,plan,root,out):
    import torch
    from torch.nn import functional as F
    directory=root/'frozen_cache';directory.mkdir(exist_ok=True)
    signature=hashlib.sha256((BASE/'protocol.json').read_bytes()).hexdigest()
    identity=directory/'identity.json'
    if identity.exists():assert json.loads(identity.read_text())['protocol_sha256']==signature
    else:save(identity,{'protocol_sha256':signature})
    def mmap(name,dtype,shape):
        path=directory/name
        value=np.lib.format.open_memmap(path,mode='r+' if path.exists() else 'w+',dtype=dtype,shape=shape)
        assert value.shape==shape and value.dtype==dtype
        return value
    h=mmap('hidden.npy',np.float16,(len(plan),1536));s=mmap('scores.npy',np.float64,(len(plan),2))
    done=mmap('done.npy',np.uint8,(len(plan),));known={r['input_sha256']:i for i,r in enumerate(plan) if done[i]}
    start=time.perf_counter();new=0;pending=[]
    model.eval()
    with torch.inference_mode():
        for i,row in enumerate(plan):
            if done[i]:continue
            prior=known.get(row['input_sha256'])
            if prior is not None:h[i]=h[prior];s[i]=s[prior];s[i,1]=0.
            else:
                ids=input_tensor(tokens,row);torch.cuda.synchronize();tick=time.perf_counter()
                hidden=model.model(input_ids=ids,use_cache=False,return_dict=True).last_hidden_state[0,-1]
                logits=F.linear(hidden.float(),model.lm_head.weight[[2753,9454]].float())
                probability=float(torch.softmax(logits,0)[1]);torch.cuda.synchronize()
                elapsed=time.perf_counter()-tick
                h[i]=hidden.float().cpu().numpy().astype(np.float16);s[i]=[probability,elapsed]
                assert np.isfinite(h[i]).all() and math.isfinite(probability)
                new+=1
            pending.append(i);known[row['input_sha256']]=i
            if len(pending)>=200 or i==len(plan)-1:
                h.flush();s.flush();done[pending]=1;done.flush();pending=[]
                progress={'stage':'frozen_cache','completed':int(done.sum()),'total':len(plan),
                          'new_forwards':new,'seconds':time.perf_counter()-start}
                save(out/'progress.json',progress)
                print(f"CACHE {progress['completed']}/{len(plan)} new={new} elapsed={progress['seconds']/60:.1f}m",flush=True)
    h.flush();s.flush()
    if pending:done[pending]=1
    done.flush();assert done.all() and np.isfinite(h).all() and np.isfinite(s).all()
    save(out/'frozen_cache_summary.json',{'rows':len(plan),'new_forwards':new,'seconds':time.perf_counter()-start})
    return h,s


def view_data(hidden,plan,view,kind='hidden'):
    ix=[i for i,r in enumerate(plan) if r['view']==view];meta=[plan[i] for i in ix]
    raw=np.asarray(hidden[ix],dtype=np.float32) if kind=='hidden' else np.log1p(np.array(
        [[r['document_count'],r['tokens'],r['characters']] for r in meta],dtype=np.float32))
    mask=np.array([r['split']=='train' for r in meta]);mean=raw[mask].mean(0);scale=raw[mask].std(0)
    scale[scale<1e-6]=1.;return (raw-mean)/scale,meta,mean,scale


def frozen_heads(hidden,scores,plan,protocol,root,out):
    target=root/'frozen_heads';target.mkdir(exist_ok=True)
    saved=target/'predictions.npz';selection_path=target/'selection.json'
    if saved.exists() and selection_path.exists():
        with np.load(saved,allow_pickle=False) as a:predictions={k:a[k] for k in a.files}
        shutil.copyfile(selection_path,out/'frozen_selection.json');return predictions
    methods={'frozen_full':('full','hidden'),'frozen_bm25_8':('bm25_8','hidden'),
             'frozen_titlegraph_8':('titlegraph_8','hidden'),'length_CE':('full','length')}
    predictions={};selection={}
    for view in VIEWS:
        ix=[i for i,r in enumerate(plan) if r['view']==view]
        predictions['prompt_'+view]=np.asarray(scores[ix,0])[None,:]
    for name,(view,kind) in methods.items():
        x,meta,mean,scale=view_data(hidden,plan,view,kind)
        train=np.array([r['split']=='train' for r in meta]);dev=np.array([r['split']=='dev' for r in meta])
        y=np.array([r['label'] for r in meta]);assert train.sum()%4==0
        data=x[train].reshape(int(train.sum())//4,2,2,-1)
        candidates={};grid=[];cfg={'augmented':True,'inv':0.,'rank':0.}
        for l2 in [.001,.01]:
            for lr in [.001,.01]:
                auc=[]
                for seed in protocol['seeds']:
                    w,b,trace=fit_head(data,cfg,l2,seed,epochs=20,batch=64,lr=lr)
                    auc.append(metrics(y[dev],sigmoid(x[dev]@w+b),.5)['AUROC'])
                    candidates[(l2,lr,seed)]=(w,b,trace)
                grid.append({'l2':l2,'lr':lr,'dev_AUROC':float(np.mean(auc))})
        best=max(grid,key=lambda v:(v['dev_AUROC'],v['l2'],-v['lr']))
        predictions[name]=np.array([sigmoid(x@candidates[(best['l2'],best['lr'],seed)][0]+
            candidates[(best['l2'],best['lr'],seed)][1]) for seed in protocol['seeds']])
        selection[name]={'grid':grid,'selected':best}
        for seed in protocol['seeds']:
            w,b,trace=candidates[(best['l2'],best['lr'],seed)]
            np.savez_compressed(target/f'{name}_{seed}.npz',weight=w,bias=b,mean=mean,scale=scale)
        print('FROZEN HEAD',name,best,flush=True)
    np.savez_compressed(saved,**predictions);save(selection_path,selection);save(out/'frozen_selection.json',selection)
    return predictions


def atomic_torch_save(path,value):
    import torch
    temporary=path.with_suffix('.tmp');torch.save(value,temporary);temporary.replace(path)


def evaluate_dev(model,tokens,plan,dev_indices):
    import torch
    from adapters import binary_logits
    model.eval();probabilities=[];labels=[]
    with torch.inference_mode():
        for i in dev_indices:
            logits=binary_logits(model,input_tensor(tokens,plan[i]))
            probabilities.append(float(torch.softmax(logits,0)[1]));labels.append(plan[i]['label'])
    model.train();return metrics(np.array(labels),np.array(probabilities),.5)['AUROC']


def train_adapter(model,tokens,plan,groups,protocol,root,name,seed):
    import torch
    from adapters import adapter_state,load_adapter,binary_logits,group_loss
    directory=root/'adapters'/f'{name}_seed{seed}';directory.mkdir(parents=True,exist_ok=True)
    complete=directory/'completed.json';best_path=directory/'best.pt';checkpoint=directory/'resume.pt'
    if complete.exists():
        assert best_path.exists(),'Completed run is missing its selected adapter'
        return json.loads(complete.read_text(encoding='utf-8')),best_path
    torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    # Reinitialize all adapter matrices identically for the same seed across losses.
    with torch.no_grad():
        for module in model.modules():
            if hasattr(module,'a') and hasattr(module,'b'):
                torch.nn.init.kaiming_uniform_(module.a,a=math.sqrt(5));module.b.zero_()
    train_groups=[g for g in groups if g['split']=='train'];lookup={}
    for i,r in enumerate(plan):
        if r['view']=='full' and r['split']=='train':lookup[(r['group_id'],r['condition'],r['label'])]=i
    dev_indices=[i for i,r in enumerate(plan) if r['view']=='full' and r['split']=='dev']
    order=np.random.default_rng(seed).permutation(len(train_groups)).tolist()
    optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=protocol['learning_rate'],weight_decay=.01)
    processed=0;step=0;best=-1.;history=[];start=time.perf_counter();loss_window=[]
    if checkpoint.exists():
        saved=torch.load(checkpoint,map_location='cpu',weights_only=False)
        load_adapter(model,saved['adapter']);optimizer.load_state_dict(saved['optimizer'])
        processed=saved['processed'];step=saved['step'];best=saved['best'];history=saved['history']
    started_processed=processed
    accumulate=protocol['accumulate_groups'];total_updates=math.ceil(len(order)/accumulate)
    warmup=max(1,round(total_updates*protocol['warmup_fraction']))
    evaluation_steps={min(len(order),math.ceil(len(order)*fraction/accumulate)*accumulate)
                      for fraction in protocol['selection_checkpoints']}
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.train()
    optimizer.zero_grad(set_to_none=True)
    weights=protocol['losses'][name]
    while processed<len(order):
        end=min(processed+accumulate,len(order))
        factor=(step+1)/warmup if step<warmup else max(0.,(total_updates-step)/max(total_updates-warmup,1))
        current_lr=protocol['learning_rate']*factor
        for param_group in optimizer.param_groups:param_group['lr']=current_lr
        for position in range(processed,end):
            group=train_groups[order[position]];logits=[]
            for condition in ['n12','n20']:
                for label in [0,1]:
                    row=plan[lookup[(group['group_id'],condition,label)]]
                    logits.append(binary_logits(model,input_tensor(tokens,row)))
            combined=torch.stack(logits).reshape(2,2,2)
            loss,parts=group_loss(combined,weights[0],weights[1]);assert torch.isfinite(loss)
            (loss/(end-processed)).backward();loss_window.append(float(loss.detach()))
        assert any(p.grad is not None and bool(torch.any(p.grad!=0)) for p in model.parameters() if p.requires_grad)
        assert all(p.grad is None for p in model.parameters() if not p.requires_grad)
        norm_value=torch.nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad],protocol['max_grad_norm'])
        assert torch.isfinite(norm_value)
        optimizer.step();optimizer.zero_grad(set_to_none=True);step+=1;processed=end
        if processed in evaluation_steps:
            auc=evaluate_dev(model,tokens,plan,dev_indices)
            history.append({'processed_groups':processed,'dev_AUROC':auc,'seconds_this_invocation':time.perf_counter()-start})
            if auc>best:
                best=auc;atomic_torch_save(best_path,adapter_state(model))
            print('DEV',name,seed,processed,'AUROC',round(auc,4),'best',round(best,4),flush=True)
        if processed%100==0 or processed in evaluation_steps or processed==len(order):
            atomic_torch_save(checkpoint,{'adapter':adapter_state(model),'optimizer':optimizer.state_dict(),
                'processed':processed,'step':step,'best':best,'history':history})
            progress={'method':name,'seed':seed,'processed_groups':processed,'total_groups':len(order),
                'mean_loss_window':float(np.mean(loss_window)),'seconds_this_invocation':time.perf_counter()-start,
                'learning_rate':current_lr,'gradient_norm':float(norm_value),
                'peak_allocated_gib':torch.cuda.max_memory_allocated()/1024**3}
            progress['estimated_remaining_this_run_minutes']=(len(order)-processed)*(time.perf_counter()-start)/max(processed-started_processed,1)/60
            save(directory/'progress.json',progress);loss_window=[]
            print('TRAIN',name,seed,f'{processed}/{len(order)}',f'{progress["seconds_this_invocation"]/60:.1f}m',
                  f'ETA current run {progress["estimated_remaining_this_run_minutes"]:.1f}m',flush=True)
    assert best_path.exists()
    result={'method':name,'seed':seed,'best_dev_AUROC':best,'dev_history':history,'processed_groups':processed,
        'updates':step,'seconds_this_invocation':time.perf_counter()-start,'base_gradients':'none'}
    save(complete,result);return result,best_path


def predict_adapter(model,tokens,plan,root,name,seed,best_path):
    import torch
    from adapters import load_adapter,binary_logits
    indices=[i for i,r in enumerate(plan) if r['view']=='full']
    path=root/'adapters'/f'{name}_seed{seed}'/'predictions.npy'
    if path.exists():
        values=np.load(path,allow_pickle=False);assert values.shape==(len(indices),);return values
    load_adapter(model,torch.load(best_path,map_location='cpu',weights_only=False));model.eval()
    values=np.zeros(len(indices),dtype=np.float64)
    with torch.inference_mode():
        for j,i in enumerate(indices):
            if plan[i]['split']=='train':values[j]=.5;continue
            logits=binary_logits(model,input_tensor(tokens,plan[i]));values[j]=float(torch.softmax(logits,0)[1])
            if (j+1)%1000==0:print('PREDICT',name,seed,j+1,'/',len(indices),flush=True)
    assert np.isfinite(values).all();np.save(path,values);return values


def clusters(groups,ids):
    table={g['group_id']:g for g in groups};parent=list(range(len(ids)));owner={}
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for i,gid in enumerate(ids):
        for key in table[gid]['source_keys']:
            if key in owner:parent[find(i)]=find(owner[key])
            else:owner[key]=i
    buckets={}
    for i in range(len(ids)):buckets.setdefault(find(i),[]).append(i)
    return [np.array(v) for v in buckets.values()]


def summarize(predictions,plan,groups,out):
    meta=[r for r in plan if r['view']=='full'];y=np.array([r['label'] for r in meta])
    calibration=np.array([r['split']=='calibration' for r in meta]);cuts={};results={}
    for name,values in predictions.items():
        assert values.shape[1]==len(meta) and np.isfinite(values).all()
        cuts[name]=[threshold(y[calibration],p[calibration]) for p in values]
        results[name]={'thresholds':cuts[name],'datasets':{}}
        for dataset in ['MuSiQue','HotpotQA','IIRC']:
            results[name]['datasets'][dataset]={}
            for condition in ['n12','n20','n32','n40','dup4','shuffle']:
                mask=np.array([r['split']=='test' and r['dataset']==dataset and r['condition']==condition for r in meta])
                if not mask.any():continue
                values_per_seed=[metrics(y[mask],p[mask],cut) for p,cut in zip(values,cuts[name])]
                results[name]['datasets'][dataset][condition]={'question_groups':int(mask.sum())//2,'per_seed':values_per_seed,
                    'mean':{k:float(np.mean([v[k] for v in values_per_seed])) for k in values_per_seed[0]},
                    'sd':{k:float(np.std([v[k] for v in values_per_seed],ddof=1)) if len(values_per_seed)>1 else 0. for k in values_per_seed[0]}}
    comparisons={};targets={}
    for dataset in ['MuSiQue','HotpotQA','IIRC']:
        ix=np.flatnonzero(np.array([r['split']=='test' and r['dataset']==dataset and r['condition']=='n40' for r in meta]))
        assert all(meta[ix[j]]['group_id']==meta[ix[j+1]]['group_id'] for j in range(0,len(ix),2))
        components=clusters(groups,[meta[i]['group_id'] for i in ix[::2]])
        distributions={k:[] for k in ['AUROC','FAR','TPR']};rng=np.random.default_rng(20261025)
        for _ in range(2000):
            selected=np.concatenate([components[j] for j in rng.integers(len(components),size=len(components))])
            chosen=ix[(selected[:,None]*2+np.array([0,1])).reshape(-1)]
            a=[metrics(y[chosen],p[chosen],cut) for p,cut in zip(predictions['lora_CE_rank_inv'],cuts['lora_CE_rank_inv'])]
            b=[metrics(y[chosen],p[chosen],cut) for p,cut in zip(predictions['lora_CE'],cuts['lora_CE'])]
            for key in distributions:distributions[key].append(float(np.mean([v[key] for v in a])-np.mean([v[key] for v in b])))
        estimate={k:results['lora_CE_rank_inv']['datasets'][dataset]['n40']['mean'][k]-results['lora_CE']['datasets'][dataset]['n40']['mean'][k] for k in distributions}
        comparisons[dataset]={'source_components':len(components),'largest_component_questions':max(len(v) for v in components),
            'differences':{k:{'estimate':estimate[k],'ci95':np.quantile(v,[.025,.975]).tolist(),
                'ci98_333_family3':np.quantile(v,[.05/6,1-.05/6]).tolist()} for k,v in distributions.items()}}
        targets[dataset]={'point_target_met':estimate['FAR']<=-.03 and estimate['TPR']>=-.02,
            'family_interval_gate_met':len(components)>=30 and max(len(v) for v in components)<=.25*(len(ix)//2)
                and comparisons[dataset]['differences']['FAR']['ci98_333_family3'][1]<0
                and comparisons[dataset]['differences']['TPR']['ci98_333_family3'][0]>=-.02}
    save(out/'formal_results.json',{'scope':'Original annotated evidence-unit coverage only; not independently audited semantic sufficiency.',
        'methods':results,'primary_comparisons':comparisons,'decision_by_dataset':targets,
        'uncertainty':'2000 shared-source-component bootstrap resamples; fitted seeds and thresholds fixed. Three dataset-family intervals use Bonferroni98.333%. No retraining/calibration uncertainty. Other comparisons exploratory.'})
    with (out/'predictions.jsonl').open('w',encoding='utf-8') as f:
        for j,r in enumerate(meta):
            if r['split']!='train':f.write(json.dumps(dict(r,scores={n:v[:,j].tolist() for n,v in predictions.items()}),ensure_ascii=False)+'\n')
    lines=['# 正式控制实验结果','','标签：原标注证据覆盖，不是严格语义充分性金标准。','','|方法|数据集|条件|AUROC↑|FAR↓|TPR↑|MacroF1↑|Brier↓|','|---|---|---|---:|---:|---:|---:|---:|']
    for name,value in results.items():
        for dataset,conditions_ in value['datasets'].items():
            for condition,record in conditions_.items():
                m=record['mean'];lines.append('|'+name+'|'+dataset+'|'+condition+'|'+ '|'.join(f'{m[k]:.4f}' for k in ['AUROC','FAR','TPR','MacroF1','Brier'])+'|')
    (out/'实际结果表.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('DECISION',json.dumps(targets,ensure_ascii=False),flush=True)


def worker(root,out):
    report={'status':'started','semantic_gold_validated':False,'errors':[]};save(out/'summary.json',report)
    start=time.perf_counter()
    try:
        protocol,groups,plan=validate();self_check()
        import torch
        import adapters
        adapters.self_check()
        model,tokenizer,info=load_model();save(out/'model_loading_info.json',info)
        import importlib.metadata
        report['versions']={name:importlib.metadata.version(name) for name in ['torch','transformers','tokenizers','numpy']}
        tokens=token_array(plan)
        # Check rendering/tokenizer agreement on rows spanning all datasets/roles, then use pinned token file.
        corpus=json.loads((BASE/'corpus.json').read_text(encoding='utf-8'))
        lookup={g['group_id']:g for g in groups};checks=[]
        for category in sorted({r['dataset']+':'+r['split'] for r in plan}):
            checks.extend([i for i,r in enumerate(plan) if r['dataset']+':'+r['split']==category][:6])
        checks.append(max(range(len(plan)),key=lambda i:plan[i]['tokens']))
        for i in checks:
            row=plan[i];g=lookup[row['group_id']];docs=select(g['question'],context(g,corpus,row['condition'],row['label']),row['view'],protocol['graph_weight'])
            rendered=tokenizer.apply_chat_template(messages(g['question'],docs),tokenize=False,add_generation_prompt=True)
            ids=tokenizer.encode(rendered,add_special_tokens=False)
            assert ids==tokens[row['offset']:row['offset']+row['tokens']].tolist()
        report.update(stage='frozen_features',render_checks=len(checks),groups=len(groups),rows=len(plan));save(out/'summary.json',report)
        hidden,scores=cache_features(model,tokens,plan,root,out)
        predictions=frozen_heads(hidden,scores,plan,protocol,root,out)
        names=adapters.install(model,protocol['rank'],protocol['alpha'])
        model.eval()
        with torch.inference_mode():
            initial=float(torch.softmax(adapters.binary_logits(model,input_tensor(tokens,plan[0])),0)[1])
            assert abs(initial-float(scores[0,0]))<=.001,'Zero adapters changed frozen model score'
        save(out/'adapter_architecture.json',{'projections':names,'trainable_parameters':sum(p.numel() for p in model.parameters() if p.requires_grad)})
        selections={};paths={}
        for name in protocol['losses']:
            for seed in protocol['seeds']:
                report.update(stage='adapter_training',method=name,seed=seed);save(out/'summary.json',report)
                selection,path=train_adapter(model,tokens,plan,groups,protocol,root,name,seed)
                selections[name+':'+str(seed)]=selection;paths[(name,seed)]=path
                save(out/'adapter_selection.json',selections)
        save(out/'all_models_frozen.json',{'utc':datetime.now(timezone.utc).isoformat(),
            'test_metrics_used':False,'selection_sha256':hashlib.sha256((out/'adapter_selection.json').read_bytes()).hexdigest()})
        for name in protocol['losses']:
            predictions[name]=np.array([predict_adapter(model,tokens,plan,root,name,seed,paths[(name,seed)]) for seed in protocol['seeds']])
        report['stage']='formal_evaluation';save(out/'summary.json',report)
        summarize(predictions,plan,groups,out)
        # Compact trained weights and baseline heads are returned; optimizers/caches stay on server.
        (out/'trained_adapters').mkdir(exist_ok=True)
        for (name,seed),path in paths.items():shutil.copyfile(path,out/'trained_adapters'/f'{name}_seed{seed}.pt')
        (out/'frozen_heads').mkdir(exist_ok=True)
        for path in (root/'frozen_heads').glob('*.npz'):
            if path.name!='predictions.npz':shutil.copyfile(path,out/'frozen_heads'/path.name)
        report.update(status='completed',stage='done',elapsed_seconds=time.perf_counter()-start,
            trained_adapter_runs=len(paths),gpu=torch.cuda.get_device_name(0),
            peak_allocated_gib=torch.cuda.max_memory_allocated()/1024**3,
            warning='Completed pipeline does not imply effectiveness, novelty, or semantic sufficiency validation.')
        save(out/'summary.json',report);return 0
    except Exception as error:
        report.update(status='failed',elapsed_seconds=time.perf_counter()-start);report['errors'].append(repr(error))
        save(out/'summary.json',report);traceback.print_exc();return 1


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('/root/autodl-tmp/paper4_formal_v2'))
    parser.add_argument('--worker',action='store_true');parser.add_argument('--run-dir',type=Path)
    parser.add_argument('--self-test',action='store_true');args=parser.parse_args()
    if args.self_test:
        protocol,groups,plan=validate();self_check();print('PACKAGE PASS',len(groups),len(plan),'GPU not exercised.');return 0
    if args.worker:return worker(args.output.resolve(),args.run_dir.resolve())
    root=args.output.resolve();root.mkdir(parents=True,exist_ok=True);lock=root/'running.pid'
    if lock.exists():
        try:os.kill(int(lock.read_text()),0)
        except ProcessLookupError:pass
        else:raise RuntimeError('A worker is still running; do not start a second writer.')
    lock.write_text(str(os.getpid()));proc=None
    out=root/('formal_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ'));out.mkdir()
    try:
        for name in ['protocol.json','data_summary.json','core.py','adapters.py','run_formal.py']:
            shutil.copyfile(BASE/name,out/name)
        with (out/'run.log').open('w',encoding='utf-8') as log:
            proc=subprocess.Popen([sys.executable,'-u',str(Path(__file__).resolve()),'--worker','--output',str(root),'--run-dir',str(out)],
                stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1)
            lock.write_text(str(proc.pid))
            for line in proc.stdout:print(line,end='',flush=True);log.write(line);log.flush()
            code=proc.wait()
        report=json.loads((out/'summary.json').read_text(encoding='utf-8')) if (out/'summary.json').exists() else {'status':'failed'}
        report['worker_exit_code']=code
        if code:report['status']='failed'
        save(out/'summary.json',report)
        print('STATUS:',report['status'],'\nRETURN_THIS_FILE:',shutil.make_archive(str(out),'zip',root_dir=out),flush=True)
        return code
    finally:
        if proc is not None and proc.poll() is None:
            proc.terminate()
            try:proc.wait(timeout=15)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
        lock.unlink(missing_ok=True)


if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    raise SystemExit(main())
