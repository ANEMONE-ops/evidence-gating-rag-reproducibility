"""Minimal LoRA on frozen Qwen q/v projections; no PEFT dependency."""
import math
import torch
from torch import nn
from torch.nn import functional as F


class LoRALinear(nn.Module):
    def __init__(self, base, rank=8, alpha=16):
        super().__init__(); self.base=base; self.scale=alpha/rank
        self.a=nn.Parameter(torch.empty(rank,base.in_features,device=base.weight.device,dtype=torch.float32))
        self.b=nn.Parameter(torch.zeros(base.out_features,rank,device=base.weight.device,dtype=torch.float32))
        nn.init.kaiming_uniform_(self.a,a=math.sqrt(5));self.base.requires_grad_(False)

    def forward(self,x):
        original=self.base(x)
        update=F.linear(F.linear(x.float(),self.a),self.b)
        return original+update.to(original.dtype)*self.scale


def install(model,rank=8,alpha=16):
    model.requires_grad_(False); names=[]
    for name,module in list(model.named_modules()):
        if name.endswith(('.q_proj','.v_proj')) and isinstance(module,nn.Linear):
            parent_name,attr=name.rsplit('.',1)
            parent=model.get_submodule(parent_name)
            setattr(parent,attr,LoRALinear(module,rank,alpha));names.append(name)
    assert names,'No Qwen attention projections found'
    return names


def adapter_state(model):
    return {name:p.detach().cpu().clone() for name,p in model.named_parameters() if p.requires_grad}


def load_adapter(model,state):
    parameters={name:p for name,p in model.named_parameters() if p.requires_grad}
    assert set(parameters)==set(state)
    with torch.no_grad():
        for name,p in parameters.items():p.copy_(state[name].to(device=p.device,dtype=p.dtype))


def binary_logits(model,input_ids):
    hidden=model.model(input_ids=input_ids,use_cache=False,return_dict=True).last_hidden_state[0,-1]
    # No and Yes are each single tokens. Compute only these output rows, not vocab x sequence.
    weight=model.lm_head.weight[[2753,9454]].float()
    bias=None if model.lm_head.bias is None else model.lm_head.bias[[2753,9454]].float()
    return F.linear(hidden.float(),weight,bias)


def group_loss(logits,rank_weight=0.,inv_weight=0.):
    # shape condition(12,20) x label(negative,positive) x class(No,Yes)
    assert logits.shape==(2,2,2)
    target=torch.tensor([0,1,0,1],device=logits.device)
    ce=F.cross_entropy(logits.reshape(-1,2),target)
    odds=logits[...,1]-logits[...,0]
    rank=F.softplus(1.-(odds[:,1]-odds[:,0])).mean()
    inv=(torch.sigmoid(odds[1])-torch.sigmoid(odds[0])).square().mean()
    return ce+rank_weight*rank+inv_weight*inv,{'CE':float(ce.detach()),'rank':float(rank.detach()),'invariance':float(inv.detach())}


def self_check():
    torch.set_num_threads(1);torch.manual_seed(19)
    base=nn.Linear(6,5);x=torch.randn(3,6);expected=base(x).detach().clone()
    layer=LoRALinear(base,2,4)
    assert torch.equal(layer(x),expected)
    layer(x).square().mean().backward()
    assert layer.b.grad.abs().sum()>0 and base.weight.grad is None
    with torch.no_grad():layer.b.add_(.01)
    merged=F.linear(x,base.weight+layer.scale*(layer.b@layer.a),base.bias)
    assert torch.allclose(layer(x),merged,atol=1e-6)
    logits=torch.tensor([[[2.,-1.],[-1.,2.]],[[1.,-1.],[-1.,1.]]],requires_grad=True)
    loss,_=group_loss(logits,.2,.05);loss.backward();assert torch.isfinite(logits.grad).all()
    # Real tiny Qwen verifies the module interface, LM-row gradient and checkpoint path.
    from transformers import Qwen2Config,AutoModelForCausalLM
    cfg=Qwen2Config(vocab_size=9500,hidden_size=32,intermediate_size=64,num_hidden_layers=2,
                   num_attention_heads=4,num_key_value_heads=2,max_position_embeddings=128,
                   tie_word_embeddings=True,attention_dropout=0.)
    cfg._attn_implementation='eager'
    model=AutoModelForCausalLM.from_config(cfg);model.eval()
    ids=torch.tensor([[4,9,12,42,31,7]])
    with torch.no_grad():before=binary_logits(model,ids)
    names=install(model,2,4);assert len(names)==4
    with torch.no_grad():assert torch.equal(before,binary_logits(model,ids))
    initial=adapter_state(model)
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.train()
    optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=.02)
    initial_loss=None
    for _ in range(16):
        optimizer.zero_grad();z=binary_logits(model,ids)
        loss=F.cross_entropy(z[None],torch.tensor([1]));initial_loss=float(loss) if initial_loss is None else initial_loss
        loss.backward();assert any(p.grad is not None and p.grad.abs().sum()>0 for p in model.parameters() if p.requires_grad)
        assert all(p.grad is None for p in model.parameters() if not p.requires_grad)
        optimizer.step()
    model.eval()
    with torch.no_grad():after=binary_logits(model,ids)
    assert float(F.cross_entropy(after[None],torch.tensor([1])))<initial_loss
    trained=adapter_state(model);load_adapter(model,initial)
    with torch.no_grad():assert torch.equal(before,binary_logits(model,ids))
    load_adapter(model,trained)
    with torch.no_grad():assert torch.equal(after,binary_logits(model,ids))
    print('PASS: zero-init, merged equivalence, frozen weights, real tiny-Qwen learning/checkpointing, adapter restore.')


if __name__=='__main__':self_check()
