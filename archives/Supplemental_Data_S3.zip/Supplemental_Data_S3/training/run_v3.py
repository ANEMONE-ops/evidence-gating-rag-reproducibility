"""One continuous job: first normal update/validation -> every fit -> all evaluations -> QA."""
import os
for k,v in {'HF_HUB_OFFLINE':'1','TRANSFORMERS_OFFLINE':'1','MKL_THREADING_LAYER':'SEQUENTIAL','OMP_NUM_THREADS':'8','OPENBLAS_NUM_THREADS':'8','PYTORCH_CUDA_ALLOC_CONF':'max_split_size_mb:128'}.items():os.environ.setdefault(k,v)
import argparse
from datetime import datetime,timezone
import hashlib,json,math,shutil,signal,sys,time,traceback
from pathlib import Path
import numpy as np
from core import jsonlines,save,metrics
import legacy_runner as engine
from tasks import METHODS

BASE=Path(__file__).resolve().parent


def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()


def validate():
    cfg=json.loads((BASE/'protocol.json').read_text(encoding='utf-8'))
    for name,value in cfg['files_sha256'].items():assert sha(BASE/name)==value,'Changed file: '+name
    plan=jsonlines(BASE/'plan.jsonl');train=jsonlines(BASE/'train_groups.jsonl');tokens=np.memmap(BASE/'token_ids.bin',mode='r',dtype='<i4')
    assert len(train)==cfg['training_questions'] and set(cfg['methods'])==set(METHODS)
    assert len({r['sample_id'] for r in plan})==len(plan)
    offset=0
    for r in plan:
        assert r['offset']==offset and 0<r['tokens']<=12288
        offset+=r['tokens'];assert hashlib.sha256(tokens[r['offset']:offset].tobytes()).hexdigest()==r['input_sha256']
    assert len(tokens)==offset
    for g in train:
        assert len(g['global_rows'])==6 and g['auxiliary_rows']
        assert all(plan[i]['group_id']==g['group_id'] and plan[i]['split']=='train' and plan[i]['task']=='global' for i in g['global_rows'])
        assert all(set(a)=={'positive','context_negative','answer_negative'} for a in g['auxiliary_rows'])
    return cfg,plan,train,tokens


def backward_group(model,tokens,plan,group,method,aux_index,aux_weight,divisor,device='cuda:0'):
    """Sequential backward releases each sequence graph; one sequence is the microbatch."""
    import torch
    from torch.nn import functional as F
    from adapters import binary_logits
    total=global_loss=aux_loss=0.
    jobs=[(i,1/len(group['global_rows']),False) for i in group['global_rows']]
    aux=group['auxiliary_rows'][aux_index%len(group['auxiliary_rows'])]
    jobs += [(aux[k],aux_weight*w,True) for k,w in METHODS[method]]
    for i,weight,is_aux in jobs:
        r=plan[i];logits=binary_logits(model,engine.input_tensor(tokens,r,device))
        loss=F.cross_entropy(logits[None],torch.tensor([r['label']],device=device))
        if not bool(torch.isfinite(loss)):raise FloatingPointError('Non-finite training loss')
        (loss*weight/divisor).backward();value=float(loss.detach())*weight;total+=value
        if is_aux:aux_loss+=value
        else:global_loss+=value
    return dict(total=total,global_loss=global_loss,auxiliary_loss=aux_loss)


def evaluate(model,tokens,plan,indices,device='cuda:0'):
    import torch
    from adapters import binary_logits
    model.eval();values=[]
    with torch.inference_mode():
        for i in indices:values.append(float(torch.softmax(binary_logits(model,engine.input_tensor(tokens,plan[i],device)),0)[1]))
    y=np.array([plan[i]['label'] for i in indices]);result=metrics(y,np.asarray(values),.5)
    assert all(np.isfinite(v) for v in result.values());return result


def train_one(model,tokens,plan,groups,cfg,root,method,seed,queue_index):
    import torch
    from adapters import adapter_state,load_adapter
    folder=root/'models'/f'{method}_seed{seed}';folder.mkdir(parents=True,exist_ok=True)
    complete=folder/'completed.json';best_path=folder/'best.pt';checkpoint=folder/'resume.pt'
    if complete.exists():assert best_path.exists();return json.loads(complete.read_text()),best_path
    torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    with torch.no_grad():
        for module in model.modules():
            if hasattr(module,'a') and hasattr(module,'b'):torch.nn.init.kaiming_uniform_(module.a,a=math.sqrt(5));module.b.zero_()
    order=np.concatenate([np.random.default_rng(seed+epoch).permutation(len(groups)) for epoch in range(cfg['epochs'])]).tolist()
    optimizer=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=cfg['learning_rate'],weight_decay=cfg['weight_decay'])
    processed=step=0;best=-1.;history=[];training_seconds=0.
    if checkpoint.exists():
        state=torch.load(checkpoint,map_location='cpu',weights_only=False);load_adapter(model,state['adapter']);optimizer.load_state_dict(state['optimizer'])
        processed=state['processed'];step=state['step'];best=state['best'];history=state['history'];training_seconds=state['training_seconds']
        torch.set_rng_state(state['torch_rng']);torch.cuda.set_rng_state_all(state['cuda_rng'])
    initial=processed;start=time.perf_counter();acc=cfg['accumulate_groups'];updates=math.ceil(len(order)/acc);warmup=max(1,round(updates*cfg['warmup_fraction']))
    selection={min(len(order),math.ceil(len(order)*fraction/acc)*acc) for fraction in cfg['selection_checkpoints']}
    dev=[i for i,r in enumerate(plan) if r['family']=='controlled' and r['split']=='dev' and r['condition']=='n40']
    model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False});model.train();optimizer.zero_grad(set_to_none=True)
    parameters=[p for p in model.parameters() if p.requires_grad];window=[]
    def persist():
        engine.atomic_torch_save(checkpoint,dict(adapter=adapter_state(model),optimizer=optimizer.state_dict(),processed=processed,step=step,best=best,history=history,
            training_seconds=training_seconds+time.perf_counter()-start,torch_rng=torch.get_rng_state(),cuda_rng=torch.cuda.get_rng_state_all()))
    try:
        while processed<len(order):
            end=min(processed+acc,len(order));factor=(step+1)/warmup if step<warmup else max(0.,(updates-step)/max(updates-warmup,1))
            for p in optimizer.param_groups:p['lr']=cfg['learning_rate']*factor
            for position in range(processed,end):
                group=groups[order[position]];hop=int(hashlib.sha256((group['group_id']+':'+str(seed)+':'+str(position//len(groups))).encode()).hexdigest()[:16],16)
                part=backward_group(model,tokens,plan,group,method,hop,cfg['auxiliary_weight'],end-processed);window.append(part)
            norm=torch.nn.utils.clip_grad_norm_(parameters,cfg['max_grad_norm'])
            if not bool(torch.isfinite(norm)):raise FloatingPointError('Non-finite gradient norm')
            assert any(p.grad is not None and bool(torch.any(p.grad!=0)) for p in parameters),'No adapter gradients'
            assert all(p.grad is None for p in model.parameters() if not p.requires_grad),'Frozen backbone received gradients'
            optimizer.step();optimizer.zero_grad(set_to_none=True);processed=end;step+=1
            # First ordinary update and validation is the ONLY server engineering boundary.
            # Accuracy/AUROC values never control whether the remaining queue runs.
            if not (root/'engineering_pass.json').exists():
                check=evaluate(model,tokens,plan,dev[:2]);save(root/'engineering_pass.json',dict(passed=True,normal_training_step=step,loss=part['total'],validation=check,effect_threshold=None,continuation='automatic full queue'))
                print('ENGINEERING PASS: finite training loss and validation; continuing ALL formal runs automatically.',flush=True);model.train();persist()
            if processed in selection:
                result=evaluate(model,tokens,plan,dev);history.append(dict(processed=processed,**result))
                if result['AUROC']>best:best=result['AUROC'];engine.atomic_torch_save(best_path,adapter_state(model))
                print('DEV',method,seed,processed,'AUROC',round(result['AUROC'],5),'continuing fixed schedule',flush=True);model.train()
            if processed%20==0 or processed==len(order):
                elapsed=time.perf_counter()-start;rate=elapsed/max(processed-initial,1);remaining=(len(order)-processed)*rate
                queue_remaining=((len(cfg['queue'])-queue_index-1)*len(order)+len(order)-processed)*rate
                progress=dict(method=method,seed=seed,processed_groups=processed,total_groups=len(order),updates=step,queue_position=queue_index+1,queue_runs=len(cfg['queue']),
                    mean_total_loss=float(np.mean([x['total'] for x in window])),mean_global_loss=float(np.mean([x['global_loss'] for x in window])),mean_auxiliary_loss=float(np.mean([x['auxiliary_loss'] for x in window])),
                    current_run_eta_minutes=remaining/60,estimated_remaining_training_hours=queue_remaining/3600,eta_scope='Training estimate; excludes remaining evaluations and QA generation.',gradient_norm=float(norm),peak_allocated_GiB=torch.cuda.max_memory_allocated()/2**30)
                save(folder/'progress.json',progress);save(root/'progress.json',progress)
                with (folder/'training_log.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(progress)+'\n')
                print(f'TRAIN {method} seed{seed} {processed}/{len(order)} loss={progress["mean_total_loss"]:.4f} run ETA={remaining/60:.1f}m queue training ETA={queue_remaining/3600:.1f}h',flush=True);window=[]
            if processed%cfg['checkpoint_groups']==0 or processed in selection or processed==len(order):persist()
    except BaseException:persist();raise
    # Resume after a signal during final validation must still complete selection.
    if not best_path.exists() or not history or history[-1]['processed']!=len(order):
        result=evaluate(model,tokens,plan,dev);history.append(dict(processed=processed,**result))
        if not best_path.exists() or result['AUROC']>best:best=result['AUROC'];engine.atomic_torch_save(best_path,adapter_state(model))
        persist()
    result=dict(method=method,seed=seed,processed_groups=processed,updates=step,best_dev_AUROC=best,dev_history=history,training_seconds=training_seconds+time.perf_counter()-start)
    save(complete,result);assert best_path.exists();return result,best_path


def predict(model,tokens,plan,root,key,weight_signature):
    import torch
    from adapters import binary_logits
    ix=[i for i,r in enumerate(plan) if r['split']!='train'];folder=root/'prediction_cache';folder.mkdir(exist_ok=True);path=folder/(key+'.npz');identity=folder/(key+'.json')
    if identity.exists():assert json.loads(identity.read_text())['weight_signature']==weight_signature
    else:save(identity,dict(weight_signature=weight_signature))
    if path.exists():
        with np.load(path,allow_pickle=False) as a:p,done,ms=[a[k].copy() for k in ['probability','done','latency_ms']]
        assert p.shape==done.shape==ms.shape==(len(ix),)
    else:p=np.zeros(len(ix));done=np.zeros(len(ix),dtype=bool);ms=np.zeros(len(ix))
    def persist():
        temp=path.with_suffix('.tmp')
        with temp.open('wb') as f:np.savez_compressed(f,probability=p,done=done,latency_ms=ms)
        temp.replace(path)
    model.eval()
    try:
        with torch.inference_mode():
            for j,i in enumerate(ix):
                if done[j]:continue
                torch.cuda.synchronize();tick=time.perf_counter();value=float(torch.softmax(binary_logits(model,engine.input_tensor(tokens,plan[i])),0)[1]);torch.cuda.synchronize()
                if not math.isfinite(value) or not 0<=value<=1:raise FloatingPointError('Non-finite evaluation probability')
                p[j]=value;ms[j]=(time.perf_counter()-tick)*1000;done[j]=True
                if (j+1)%500==0:persist();print('EVAL',key,j+1,'/',len(ix),flush=True)
    finally:persist()
    assert done.all() and np.isfinite(p).all() and ((p>=0)&(p<=1)).all();return p


def generate_answers(model,tokenizer,root):
    import torch
    plan=jsonlines(BASE/'answer_plan.jsonl');tokens=np.memmap(BASE/'answer_token_ids.bin',mode='r',dtype='<i4');folder=root/'answer_cache';folder.mkdir(exist_ok=True);outputs=[]
    model.eval()
    for i,r in enumerate(plan):
        path=folder/(r['sample_id'].replace(':','__')+'.json')
        if path.exists():value=json.loads(path.read_text(encoding='utf-8'));assert value['input_sha256']==r['input_sha256']
        else:
            x=engine.input_tensor(tokens,r);torch.cuda.synchronize();tick=time.perf_counter()
            with torch.inference_mode():z=model.generate(input_ids=x,attention_mask=torch.ones_like(x),max_new_tokens=64,do_sample=False,use_cache=True,num_logits_to_keep=1,temperature=1.,top_p=1.,top_k=50,pad_token_id=tokenizer.pad_token_id or tokenizer.eos_token_id,eos_token_id=tokenizer.eos_token_id)
            torch.cuda.synchronize();ids=z[0,x.shape[1]:].tolist();text=tokenizer.decode(ids,skip_special_tokens=True)
            value=dict(sample_id=r['sample_id'],input_sha256=r['input_sha256'],candidate=text.strip(),raw_text=text,generated_token_ids=ids,generated_tokens=len(ids),hit_token_cap=len(ids)==64 and (not ids or ids[-1]!=tokenizer.eos_token_id),latency_ms=(time.perf_counter()-tick)*1000)
            temp=path.with_suffix('.tmp');save(temp,value);temp.replace(path)
        outputs.append(value)
        if (i+1)%50==0:print('INDEPENDENT QA',i+1,'/',len(plan),flush=True)
    return outputs


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('/root/autodl-tmp/paper4_formal_v3'));parser.add_argument('--self-test',action='store_true');a=parser.parse_args()
    cfg,plan,groups,tokens=validate()
    if a.self_test:print('PACKAGE PASS:',len(groups),'training questions; full queue',len(cfg['queue']),'runs; no metric gates. GPU not exercised.');return 0
    root=a.output.resolve();root.mkdir(parents=True,exist_ok=True);signature=sha(BASE/'protocol.json');identity=root/'identity.json'
    if identity.exists():assert json.loads(identity.read_text())['protocol_sha256']==signature,'Different protocol: use another output directory'
    else:save(identity,dict(protocol_sha256=signature))
    lock=root/'running.pid'
    if lock.exists():
        try:os.kill(int(lock.read_text()),0)
        except ProcessLookupError:lock.unlink()
        else:raise RuntimeError('This experiment is already running')
    with lock.open('x') as f:f.write(str(os.getpid()))
    def stop(_s,_f):raise KeyboardInterrupt()
    signal.signal(signal.SIGTERM,stop)
    out=root/('formal_v3_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ'));out.mkdir();report=dict(status='started',stage='loading',errors=[],no_effect_based_stopping=True);code=1;started=time.perf_counter()
    for name in ['protocol.json','data_summary.json','plan.jsonl','answer_plan.jsonl','train_groups.jsonl','groups.jsonl','real_groups.jsonl']:shutil.copyfile(BASE/name,out/name)
    save(out/'summary.json',report);print('LIVE_RESULTS_DIR:',out,flush=True)
    try:
        import torch,adapters
        from aggregate import summarize
        model,tokenizer,info=engine.load_model();save(out/'model_loading_info.json',info)
        for check in json.loads((BASE/'render_checks.json').read_text(encoding='utf-8')):
            r=plan[check['row_index']];assert tokenizer.apply_chat_template(check['messages'],tokenize=True,add_generation_prompt=True)==tokens[r['offset']:r['offset']+r['tokens']].tolist(),'Tokenizer rendering mismatch'
        modules=adapters.install(model,cfg['rank'],cfg['alpha']);selections={};(out/'trained_adapters').mkdir(exist_ok=True)
        save(out/'adapter_architecture.json',dict(projections=modules,trainable_parameters=sum(p.numel() for p in model.parameters() if p.requires_grad)))
        for j,job in enumerate(cfg['queue']):
            method=job['method'];seed=job['seed'];key=f'{method}_seed{seed}';report.update(stage='formal_training',method=method,seed=seed,queue_index=j+1);save(out/'summary.json',report)
            result,path=train_one(model,tokens,plan,groups,cfg,root,method,seed,j);selections[key]=result;save(out/'training_summary.json',selections)
            shutil.copyfile(path,out/'trained_adapters'/(key+'.pt'));adapters.load_adapter(model,torch.load(path,map_location='cpu',weights_only=False))
            predict(model,tokens,plan,root,key,sha(path));summarize(BASE,root,out,cfg,plan,final=False)
            print('RUN COMPLETE',j+1,'/',len(cfg['queue']),key,'Next run starts automatically.',flush=True)
        # Remove adapter updates to obtain the original backbone for both baseline and shared answers.
        with torch.no_grad():
            for module in model.modules():
                if hasattr(module,'a') and hasattr(module,'b'):module.b.zero_()
        report['stage']='untuned_baseline_and_shared_answering';save(out/'summary.json',report)
        predict(model,tokens,plan,root,'prompt_base_seed0','zero_adapter_updates:'+cfg['model_commit'])
        answers=generate_answers(model,tokenizer,root)
        (out/'independent_answers.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in answers),encoding='utf-8')
        summarize(BASE,root,out,cfg,plan,final=True,answers=answers)
        report.update(status='completed',stage='done',completed_training_runs=len(selections),evaluation_inputs_per_configuration=sum(r['split']!='train' for r in plan),independent_answers=len(answers),gpu=torch.cuda.get_device_name(0),peak_allocated_GiB=torch.cuda.max_memory_allocated()/2**30);code=0
    except KeyboardInterrupt:report.update(status='interrupted');code=130
    except Exception as e:report.update(status='failed');report['errors'].append(repr(e));traceback.print_exc()
    finally:
        report['elapsed_seconds_this_invocation']=time.perf_counter()-started;save(out/'summary.json',report)
        for name in ['prediction_cache','answer_cache']:
            if (root/name).exists():shutil.copytree(root/name,out/name,dirs_exist_ok=True)
        if (root/'engineering_pass.json').exists():shutil.copyfile(root/'engineering_pass.json',out/'engineering_pass.json')
        if (root/'models').exists():
            (out/'training_logs').mkdir(exist_ok=True)
            for folder in (root/'models').iterdir():
                if folder.is_dir():
                    for name in ['training_log.jsonl','completed.json','progress.json']:
                        if (folder/name).exists():shutil.copyfile(folder/name,out/'training_logs'/(folder.name+'_'+name))
        lock.unlink(missing_ok=True);print('STATUS:',report['status'],'\nRETURN_THIS_FILE:',shutil.make_archive(str(out),'zip',root_dir=out),flush=True)
    return code


if __name__=='__main__':raise SystemExit(main())
