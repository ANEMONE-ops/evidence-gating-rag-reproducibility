"""Pure-NumPy heads and deterministic evidence views; GPU imports live in runner."""
import hashlib
import json
import math
import re
from collections import Counter
from pathlib import Path
import numpy as np

COMMIT = '989aa7980e4cf806f80c7fef2b1adb7bc71aa306'
SYSTEM = ('Judge whether the supplied evidence is sufficient to answer the question completely. '
          'Use only the supplied evidence, not outside facts. Require evidence for the necessary '
          'entity identities and relations linking the question to its answer. Merely seeing a '
          'possible answer, a shared name, or a related attribute is not enough. Alternative complete '
          'evidence chains are allowed. For an undated numerical question, an explicitly dated answer '
          'is allowed. Interpret current or present relative to the supplied document snapshot. '
          'Reply Yes if sufficient; otherwise reply No.')
CONDITIONS = {'train': ['base', 'dup4', 'noise4'], 'dev': ['base', 'dup4', 'noise4'],
              'calibration': ['base'],
              'test': ['base', 'dup4', 'noise4', 'noise12', 'noise20', 'permuted']}
VIEWS = ['full', 'bm25_top4']
METHODS = {
    'length_CE_aug': dict(view='full', features='length', augmented=True, inv=0., rank=0.),
    'full_CE_base': dict(view='full', features='hidden', augmented=False, inv=0., rank=0.),
    'full_CE_aug': dict(view='full', features='hidden', augmented=True, inv=0., rank=0.),
    'full_CE_aug_length': dict(view='full', features='hidden_length', augmented=True, inv=0., rank=0.),
    'full_CE_inv': dict(view='full', features='hidden', augmented=True, inv=1., rank=0.),
    'full_CE_weakrank': dict(view='full', features='hidden', augmented=True, inv=0., rank=.2),
    'full_CE_inv_weakrank': dict(view='full', features='hidden', augmented=True, inv=1., rank=.2),
    'top4_CE_aug': dict(view='bm25_top4', features='hidden', augmented=True, inv=0., rank=0.),
}


def digest(value):
    return hashlib.sha256(value.encode('utf-8')).hexdigest()


def save(path, value):
    Path(path).write_bytes((json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode())


def jsonlines(path):
    with Path(path).open(encoding='utf-8') as f:
        return [json.loads(s) for s in f if s.strip()]


def words(s):
    return re.findall(r'[a-z0-9]+', s.lower())


def content_key(d):
    return digest(d['title'].strip()+'\n'+d['text'].strip())


def select_top4(question, docs):
    # Deduplication is part of this baseline and is reported explicitly.
    unique = list({content_key(d): d for d in reversed(docs)}.values())[::-1]
    counts = [Counter(words(d['title']+' '+d['text'])) for d in unique]
    lengths = [sum(c.values()) for c in counts]
    average = max(float(np.mean(lengths)), 1.)
    query = set(words(question)); n = len(unique)
    df = {t: sum(t in c for c in counts) for t in query}
    scores = [sum(math.log(1+(n-df[t]+.5)/(df[t]+.5))*c[t]*2.5 /
                  (c[t]+1.5*(.25+.75*length/average)) for t in query if c[t])
              for c, length in zip(counts, lengths)]
    indices = sorted(range(n), key=lambda i: (-scores[i], content_key(unique[i])))[:4]
    # Stable content tie-break makes permutation/duplicate controls exactly invariant.
    return [unique[i] for i in indices]


def documents(group, variant, condition, pool):
    original = group['variants'][variant]['documents']
    if condition == 'base': return original
    rng = np.random.default_rng(int(digest(group['group_id']+':'+condition)[:16], 16))
    if condition == 'permuted':
        return [original[i] for i in rng.permutation(len(original))]
    if condition == 'dup4':
        extra = [original[int(i)] for i in rng.integers(len(original), size=4)]
    else:
        count = int(condition.removeprefix('noise'))
        # Same pool/order for the paired native variants; excludes all original titles.
        excluded = {d['title'].casefold() for v in group['variants'] for d in v['documents']}
        order = np.random.default_rng(int(digest(group['group_id']+':noise')[:16], 16)).permutation(len(pool))
        extra = []; seen = {content_key(d) for v in group['variants'] for d in v['documents']}
        for i in order:
            d = pool[int(i)]; key = content_key(d)
            if d['title'].casefold() in excluded or key in seen: continue
            extra.append(d); seen.add(key)
            if len(extra) == count: break
        if len(extra) != count: raise ValueError('Insufficient distinct noise documents')
    # Insert documents throughout, rather than always putting native evidence first.
    result = list(original)
    for j, d in enumerate(extra):
        slot = int(digest(group['group_id']+':insert:'+str(j))[:8], 16) % (len(result)+1)
        result.insert(slot, d)
    return result


def messages(question, docs):
    evidence = '\n\n'.join(f"Document {i+1}: {d['title']}\n{d['text']}" for i, d in enumerate(docs))
    return [{'role': 'system', 'content': SYSTEM},
            {'role': 'user', 'content': f'Question: {question}\n\nEvidence:\n{evidence}'}]


def iter_samples(groups, pools):
    for g in groups:
        for condition in CONDITIONS[g['split']]:
            for variant in [0, 1]:
                docs = documents(g, variant, condition, pools[g['split']])
                for view in VIEWS:
                    chosen = docs if view == 'full' else select_top4(g['question'], docs)
                    meta = {'sample_id': f"{g['group_id']}:{variant}:{condition}:{view}",
                            'group_id': g['group_id'], 'split': g['split'], 'variant': variant,
                            'condition': condition, 'view': view, 'label': variant,
                            'document_count': len(chosen),
                            'context_characters': sum(len(d['title'])+len(d['text']) for d in chosen)}
                    yield meta, messages(g['question'], chosen)


def sigmoid(z):
    return np.exp(-np.logaddexp(0., -np.asarray(z)))


def threshold(y, p, target=.8):
    positive = np.sort(p[y == 1])[::-1]
    if not len(positive): raise ValueError('No calibration positives')
    return float(positive[math.ceil(target*len(positive))-1])


def metrics(y, p, cut):
    y = np.asarray(y); p = np.asarray(p)
    assert np.isfinite(p).all() and set(y) == {0, 1}
    n1 = int(y.sum()); n0 = len(y)-n1
    order = np.argsort(p, kind='stable'); sorted_p = p[order]
    starts = np.r_[0, np.flatnonzero(np.diff(sorted_p))+1]; ends = np.r_[starts[1:], len(y)]
    sorted_ranks = np.repeat((starts+ends+1)/2, ends-starts)
    auc = (sorted_ranks[y[order] == 1].sum()-n1*(n1+1)/2)/(n1*n0)
    accept = p >= cut; tp = int((accept & (y == 1)).sum()); fp = int((accept & (y == 0)).sum())
    tn = n0-fp; fn = n1-tp
    return {'AUROC': float(auc), 'FAR': fp/n0, 'TPR': tp/n1,
            'MacroF1': .5*(2*tp/max(2*tp+fp+fn, 1)+2*tn/max(2*tn+fp+fn, 1)),
            'Brier': float(np.mean((p-y)**2))}


def objective(w, bias, x, y, cfg, l2):
    """x: group x condition x native_variant(negative,positive) x feature."""
    z = x @ w + bias
    active = slice(None) if cfg['augmented'] else slice(0, 1)
    za = z[:, active]; ya = y[:, active]
    loss = float(np.mean(np.logaddexp(0., za)-ya*za)) + .5*l2*float(w@w)
    dz = np.zeros_like(z); dz[:, active] = (sigmoid(za)-ya)/za.size
    if cfg['inv']:
        # Only exact duplicate insertion gets an invariance constraint.
        # Distinct added documents can change sufficiency; never constrain them to agree.
        difference = z[:, 1]-z[:, 0]
        loss += cfg['inv']*float(np.mean(difference**2))
        delta = 2*cfg['inv']*difference/difference.size
        dz[:, 1] += delta; dz[:, 0] -= delta
    if cfg['rank']:
        # Native answerability pairs are WEAK supervision, never semantic gold.
        margin = 1.-(z[:, :, 1]-z[:, :, 0])
        loss += cfg['rank']*float(np.mean(np.logaddexp(0., margin)))
        delta = cfg['rank']*sigmoid(margin)/margin.size
        dz[:, :, 0] += delta; dz[:, :, 1] -= delta
    dw = np.einsum('gcv,gcvf->f', dz, x, optimize=True)+l2*w
    return loss, dw, float(dz.sum())


def fit_head(x, cfg, l2, seed, epochs=20, batch=64, lr=.01):
    rng = np.random.default_rng(seed); w = np.zeros(x.shape[-1], dtype=np.float32); bias = 0.
    mw = np.zeros_like(w); vw = np.zeros_like(w); mb = vb = 0.; step = 0; trace = []
    y = np.broadcast_to(np.array([0., 1.], dtype=np.float32), x.shape[:-1])
    for epoch in range(epochs):
        losses = []
        order = rng.permutation(len(x))
        for start in range(0, len(x), batch):
            ix = order[start:start+batch]; step += 1
            loss, dw, db = objective(w, bias, x[ix], y[ix], cfg, l2)
            if not np.isfinite(loss) or not np.isfinite(dw).all(): raise ValueError('Non-finite head training')
            # Same optimizer, epochs and group order budget for every trained method.
            mw = .9*mw+.1*dw; vw = .999*vw+.001*dw**2
            mb = .9*mb+.1*db; vb = .999*vb+.001*db**2
            w -= lr*(mw/(1-.9**step))/(np.sqrt(vw/(1-.999**step))+1e-8)
            bias -= lr*(mb/(1-.9**step))/(math.sqrt(vb/(1-.999**step))+1e-8)
            losses.append(loss)
        trace.append(float(np.mean(losses)))
    return w, bias, trace


def self_check():
    y = np.array([0, 0, 1, 1]); p = np.array([.9, .1, .8, .7])
    m = metrics(y, p, .75)
    assert m['AUROC'] == .5 and m['FAR'] == m['TPR'] == .5
    assert metrics(y, np.ones(4)*.5, .5)['AUROC'] == .5
    assert threshold(y, p, 1.) == .7
    rng = np.random.default_rng(12); x = rng.normal(size=(3, 3, 2, 5))
    labels = np.broadcast_to([0., 1.], x.shape[:-1]); w = rng.normal(size=5)*.1
    cfg = dict(augmented=True, inv=.3, rank=.2)
    loss, grad, db = objective(w, .2, x, labels, cfg, .01); eps = 1e-5
    for k in range(5):
        direction = np.eye(5)[k]*eps
        numerical = (objective(w+direction, .2, x, labels, cfg, .01)[0]-
                     objective(w-direction, .2, x, labels, cfg, .01)[0])/(2*eps)
        assert abs(numerical-grad[k]) < 1e-7, (numerical, grad[k])
    numerical = (objective(w, .2+eps, x, labels, cfg, .01)[0]-
                 objective(w, .2-eps, x, labels, cfg, .01)[0])/(2*eps)
    assert abs(numerical-db) < 1e-7
    easy = rng.normal(size=(80, 3, 2, 4)).astype(np.float32)
    easy[:, :, 0, 0] -= 4; easy[:, :, 1, 0] += 4
    fitted, b, trace = fit_head(easy, dict(augmented=True, inv=0., rank=0.), .001, 11)
    assert trace[-1] < trace[0] and metrics(np.tile([0, 1], 80),
        sigmoid(easy[:, 0].reshape(-1, 4)@fitted+b), .5)['AUROC'] > .98
    docs = [{'title': str(i), 'text': 'red tree' if i == 0 else 'blue lake'} for i in range(7)]
    a = select_top4('red tree', docs)
    assert a == select_top4('red tree', docs[::-1]) == select_top4('red tree', docs+docs[:4])
    assert a[0]['title'] == '0'
    print('PASS: paired objective finite differences, trainable synthetic signal, tied AUROC, calibration, BM25 controls.')


if __name__ == '__main__': self_check()
