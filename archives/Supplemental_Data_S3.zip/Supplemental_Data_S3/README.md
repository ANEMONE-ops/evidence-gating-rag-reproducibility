# Supplemental Data S3

Frozen training inputs, historical predictions and figure sources accompanying Supplemental Data S2.

## Reconstruct source training inputs and run the twelve fits

Place extracted S2 and S3 beside each other. The source entry point accepts a new output directory and leaves the frozen inputs unchanged:

```text
python reproduce_training_portable.py --s2 ../Supplemental_Data_S2 --output ./reconstructed_inputs
python reproduce_training_portable.py --s2 ../Supplemental_Data_S2 --output ./new_training_run --train
```

The first command downloads the exact public Qwen tokenizer revision, reconstructs all 65,112 distinct training views and 800 source-development inputs, and verifies every saved token hash. The second additionally downloads the fixed backbone revision and runs four constructions with matched seeds 11, 29 and 47 using the original optimizer and checkpoint-selection functions. A CUDA GPU and the documented PyTorch/Transformers versions are required for fitting. Pretrained downloads and fitted adapter checkpoints are derived assets rather than contents of these two supplemental archives.

`training/plan.jsonl` retains each selected original row identity, token count, coverage label and input hash. Row numbers are compacted to the selected union and the four recipe maps are remapped consistently. Token offsets are rebuilt by the entry point. `input_selection_manifest.json` records this lossless selection of the inputs relevant to the four recipes and source checkpoint selection. Each fit still uses 5,426 questions and 32,556 views. All four recipes use binary cross-entropy.

To recover the complete corpus, join `training/source_corpus.json` with S2 `code/data/hot_corpus.json`. Shared passages were checked for exact content equality before packaging. The source metadata supplies document identities; labels, questions and input hashes reside in the selected plan. Original frozen code files are included without changing their recorded protocols. The portable entry point calls the training functions directly and does not invoke historical launch scripts or hardcoded server directories.

## Historical metrics

`historical/record_index.jsonl` lists all 42,652 historical nontraining rows in their exact saved prediction order. The twelve `historical/prediction_cache/*.npz` files have matching row order. These enable recomputation of controlled and historical natural-context metrics; score files have no training rows. Run `python reproduce_historical_metrics.py` to verify all twelve controlled dataset-by-construction means and sample SDs against their reported four-decimal values. Frozen source protocols and training logs retain the original checkpoint-selection record.

## Figure reproduction

```text
python figure_sources/redraw_figures.py
```

The deterministic Matplotlib script reproduces the eleven original source layouts from the supplied CSV/JSON data. Original plots 5–11 correspond to current Figures 4–10. S4 supplies the current Figure 3 artwork, revised Figure 6 and public-label Figure 11. The new ROC and empirical-CDF panels use all primary-test scores, with no case sampling or smoothing. All three seeds are included. Means and sample SD are distinguished from the prespecified bootstrap intervals. PDF files use US Letter pages with one inch margins; SVG text remains editable.

## Model and data providers

Qwen2.5-1.5B-Instruct revision: 989aa7980e4cf806f80c7fef2b1adb7bc71aa306. BGE-small-en-v1.5 revision: 5c38ec7c405ec4b44b94cc5a9bb96e735b38267a. Benchmark and model providers' terms remain applicable. Input/source hashes and transformations are recorded in the archive manifests. The portable numerical checks read the saved predictions.

## Lossless compact storage

Repeated passage hashes are dictionary encoded in the `.indexed.jsonl` files to fit the publisher supplemental-size limit. `restore_inputs.py` reconstructs the original JSONL bytes and checks their saved SHA256 values. The numerical and training entry points call restoration automatically. Corpus key order is only used to decode these passage indices; prompt order is the explicit order in each restored record. No score, text, label, group or numerical value is rounded or discarded by this encoding.

Passage corpora use value-only JSON arrays. Their SHA256 passage keys are recomputed from each unchanged title and text using the original content-key function. `corpus_storage.json` records the exact original-file hashes, counts and serialization. Restoration checks the complete original corpus bytes before using their passage order. This removes redundant derived keys without deleting corpus text.

These ZIP files use the standard ZIP LZMA method. Use Python `python -m zipfile -e Supplemental_Data_S2.zip .` (and similarly S3), or an extractor supporting ZIP LZMA, to extract them.
