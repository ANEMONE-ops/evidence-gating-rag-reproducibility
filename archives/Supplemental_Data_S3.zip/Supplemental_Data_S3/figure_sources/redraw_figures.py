"""Original vector schematics and quantitative plots from frozen observations."""
from pathlib import Path
from shutil import copy2
from collections import defaultdict
import csv, json, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, FancyArrowPatch, Polygon, Circle
from matplotlib.lines import Line2D
from matplotlib.transforms import Bbox
from PIL import Image

sys.stdout.reconfigure(encoding='utf-8')
HERE=Path(__file__).resolve().parent
PORTABLE=(HERE/'source_data/primary_test_scores.csv').exists()
if PORTABLE:
    OUT=HERE/'figures';QA=HERE/'figure_audits';SRC=HERE/'source_data';SUPPORT=HERE;RAW=None
else:
    ROOT=HERE.parents[1];OUT=ROOT/'final/02_Figures';QA=ROOT/'final/QA/figure_audits'
    SRC=ROOT/'12_论文整理与复现检查/结果汇总/Electronics_English_Revised_20261102/source_data'
    RAW=ROOT/'06_正式对比实验/结果汇总/supplement_v6_actual_20261102/原始返回'
    SUPPORT=ROOT/'final/06_Reproducibility/figure_sources'
for p in [OUT,OUT/'PNG',OUT/'SVG',QA,SUPPORT,SUPPORT/'source_data']:p.mkdir(parents=True,exist_ok=True)
for p in SRC.iterdir():
    if p.suffix in ['.json','.csv'] and p.resolve()!=(SUPPORT/'source_data'/p.name).resolve():copy2(p,SUPPORT/'source_data'/p.name)
if not PORTABLE:sys.path.insert(0,'C:/Users/anymore/.agents/skills/nature-figure/scripts')
from audit_panel_alignment import require_matplotlib_panel_alignment

plt.rcParams.update({'font.family':'Arial','font.size':8.4,'axes.labelsize':8.3,'axes.titlesize':9.2,
 'xtick.labelsize':7.7,'ytick.labelsize':7.7,'legend.fontsize':7.7,'axes.linewidth':.7,
 'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white','figure.facecolor':'white'})
COL={'CE':'#63758A','NR':'#2176A5','CH':'#BE8057','NH':'#8772AF'}
PALE={'blue':'#ECF4F9','purple':'#F3EFF9','teal':'#EAF6F3','orange':'#FCF1E6','gray':'#F3F5F7','white':'#FFFFFF'}
INK='#263C4D';GRAY='#697D8C';SUP='#408F7D';NEG='#C88760'
MAP={'CE':'CE','NR':'NAT_RANDOM_CE','CH':'CORE_HARD_CE','NH':'RET_CE'}
MARK={'CE':'o','NR':'s','CH':'^','NH':'D'}
metrics=list(csv.DictReader((SRC/'gate_metrics_mean_sd.csv').open(encoding='utf-8-sig')))
curves=json.loads((SRC/'risk_coverage_curves.json').read_text(encoding='utf-8'))
primary=json.loads((SRC/'selected_results.json').read_text(encoding='utf-8'))['primary']

def metric(m,cohort='v6_unseen',retriever='HYBRID_RRF',policy='target40',condition='n40'):
    return next(r for r in metrics if r['method']==MAP[m] and r['cohort']==cohort and r['retriever']==retriever and r['policy']==policy and r['condition']==condition)

def base(height):
    f=plt.figure(figsize=(8.5,11));f._height=height
    return f
def axis(f,x,y,w,h):
    # Coordinates in the 6.5 inch artwork region, origin at its upper left.
    return f.add_axes([(1+x)/8.5,(10-y-h)/11,w/8.5,h/11])
def panel(ax,letter,title):
    ax.set_title(letter+'  '+title,loc='left',fontweight='bold',pad=12,color=INK)
def clean(ax):
    ax.spines[['top','right']].set_visible(False);ax.tick_params(length=3,width=.7,color=GRAY)
    ax.set_axisbelow(True);ax.grid(axis='y',color='#E9EDF0',lw=.65)
def save(f,n,axes=None):
    f.canvas.draw()
    if axes:
        row_groups=defaultdict(list);column_groups=defaultdict(list)
        for j,ax in enumerate(axes):
            bb=ax.get_position();row_groups[round(bb.y0,5)].append(chr(97+j));column_groups[round(bb.x0,5)].append(chr(97+j))
        require_matplotlib_panel_alignment(f,axes=axes,panel_ids=[chr(97+j) for j in range(len(axes))],row_groups=[v for v in row_groups.values() if len(v)>1],column_groups=[v for v in column_groups.values() if len(v)>1],json_out=QA/f'Figure{n}_alignment.json',overlay_svg=QA/f'Figure{n}_alignment.svg',tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
    else:
        (QA/f'Figure{n}_alignment.json').write_text(json.dumps({'status':'NOT APPLICABLE','reason':'Single axes with intentionally unequal schematic regions.'}),encoding='utf-8')
    f.savefig(OUT/f'Figure{n}.pdf')
    crop=Bbox.from_bounds(1,10-f._height,6.5,f._height)
    f.savefig(OUT/'SVG'/f'Figure{n}.svg',bbox_inches=crop)
    raster_dpi=3000/max(6.5,f._height)
    f.savefig(OUT/'PNG'/f'Figure{n}.png',bbox_inches=crop,dpi=raster_dpi)
    with Image.open(OUT/'PNG'/f'Figure{n}.png') as im:
        im=im.convert('RGB');assert min(im.size)>=900 and max(im.size)<=3000,im.size
        im.save(OUT/'PNG'/f'Figure{n}.png',dpi=(raster_dpi,raster_dpi))
        im.thumbnail((1500,1700));im.save(QA/f'Figure{n}_preview.png')
    plt.close(f)

def schematic(height):
    f=base(height);a=axis(f,0,0,6.5,height);a.set(xlim=(0,100),ylim=(height*100/6.5,0));a.axis('off');return f,a
def txt(a,x,y,text,size=8,color=INK,weight='normal',ha='left',va='center',**kw):
    text=text.translate(str.maketrans({'₁':'1','₂':'2','₀':'0','ₖ':'k'}))
    return a.text(x,y,text,fontsize=size,color=color,fontweight=weight,ha=ha,va=va,linespacing=1.35,**kw)
def box(a,x,y,w,h,label='',fill='white',edge='#B4C6D3',size=8,weight='normal',rounding=1.0):
    a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle=f'round,pad=0,rounding_size={rounding}',facecolor=PALE.get(fill,fill),edgecolor=edge,lw=.8,zorder=1))
    if label:txt(a,x+w/2,y+h/2,label,size,weight=weight,ha='center')
def arr(a,start,end,color=GRAY,style='-',rad=0):
    a.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=9,color=color,lw=.9,linestyle=style,connectionstyle=f'arc3,rad={rad}',zorder=3))
def route(a,points,color=GRAY,dashed=False):
    xx,yy=zip(*points);a.plot(xx[:-1],yy[:-1],color=color,lw=.9,ls='--' if dashed else '-',zorder=2);arr(a,points[-2],points[-1],color,'--' if dashed else '-')
def document(a,x,y,w=6,h=8,label='D',color='#D9E3EA'):
    a.add_patch(Rectangle((x+.7,y-.7),w,h,fc='#FFFFFF',ec='#CBD6DF',lw=.6))
    a.add_patch(Rectangle((x,y),w,h,fc=color,ec='#9DB2C1',lw=.6,zorder=2))
    txt(a,x+w/2,y+h*.32,label,6.7,ha='center',weight='bold')
    for yy in [.55,.7,.84]:a.plot([x+w*.2,x+w*.8],[y+h*yy,y+h*yy],color='#91A6B4',lw=.55,zorder=3)
def strip(a,x,y,labels,missing=False):
    for i,lab in enumerate(labels):document(a,x+i*6.6,y,5.1,6.7,lab,'#CBE3D9' if lab.startswith('S') else '#E5ECF1')
    if missing:txt(a,x+len(labels)*6.6+.5,y+3.4,'…',9)
def tag(a,x,y,label,fill='blue',edge=COL['NR']):box(a,x,y,5.8,4.5,label,fill,edge,7.5,'bold',.6)

# 1 — Whole system: the control interfaces are explicit and directional.
f,a=schematic(8.7)
box(a,0,0,100,44,fill='#F7FAFC',edge='#D7E2EA',rounding=1.4)
txt(a,3,3.3,'a  OFFLINE TRAINING',10,weight='bold')
txt(a,3,8.5,'5,426 MuSiQue questions',8.3,weight='bold');txt(a,3,12.5,'Annotated support passages',7.7)
document(a,4,19,7,10,'q');document(a,14,19,7,10,'S₁','#CBE3D9');document(a,24,19,7,10,'S₂','#CBE3D9')
arr(a,(32,24),(38,24))
box(a,39,9,26,28,fill='white',edge='#B5C6D4');txt(a,52,13,'FOUR CONSTRUCTIONS',7.7,ha='center',weight='bold')
for i,m in enumerate(MAP):
    xx=42+(i%2)*11;yy=18+(i//2)*10
    box(a,xx,yy,9,6.7,m,'white',COL[m],8,'bold')
txt(a,52,40,'6 views / question',7.5,ha='center')
arr(a,(66,24),(71,24))
box(a,72,12,25,21,'Frozen Qwen2.5-1.5B\n+ trainable rank-8 LoRA','purple','#A291C0',8)
txt(a,84.5,37.5,'3 seeds / construction',7.6,ha='center')
route(a,[(84.5,44),(84.5,48),(50,48),(50,55)],COL['NR'],True)
txt(a,51.5,50,'12 fixed fitted gates',7.7,color=COL['NR'])
box(a,0,55,100,57,fill='#F8FBFC',edge='#D7E2EA',rounding=1.4)
txt(a,3,59,'b  TARGET RETRIEVAL AND INDEPENDENT CALIBRATION',9.7,weight='bold')
box(a,3,66,25,13,'HotpotQA question\nBM25 / HYBRID retrieval','blue',COL['NR'],8)
document(a,5,84,5,7,'S₁','#CBE3D9');document(a,12,84,5,7,'D');document(a,19,84,5,7,'S₂','#CBE3D9')
txt(a,15.5,95,'12–40 paragraphs',7.5,ha='center')
arr(a,(29,72),(34,72));box(a,35,66,24,13,'Fixed gate\nQuestion + context → score','purple','#A291C0',7.7)
box(a,35,88,24,14,'Calibration components\nPositive-score quantile → τ','orange','#D1AB83',7.7)
route(a,[(60,95),(63,95),(63,84),(81,84),(81,80)],'#BD9166')
arr(a,(60,72),(65,72));box(a,66,66,30,13,'Test components\nAccept if score ≥ τ','teal','#6CA697',8)
route(a,[(81,80),(81,87),(73,87),(73,92)],SUP)
route(a,[(81,80),(81,87),(91,87),(91,92)])
box(a,66,93,15,8,'Accept','teal',SUP,7.8,'bold');box(a,84,93,13,8,'Reject','gray',GRAY,7.8)
txt(a,64,107,'Decision endpoints: FAR and TPR',7.7,weight='bold')
txt(a,2,118,'c  SHARED-ANSWER EVALUATION',9.2,weight='bold')
box(a,2,123,27,8,'One fixed reader answer','gray',GRAY,7.8)
arr(a,(30,127),(36,127));box(a,37,123,26,8,'Same candidate for all gates','teal',SUP,7.4)
arr(a,(64,127),(70,127));box(a,71,123,27,8,'EM · Yield · Risk–coverage','blue',COL['NR'],7.4)
save(f,1)

# 2 — Four actual constructions, with support identities drawn rather than hidden.
f,a=schematic(8.5)
txt(a,0,3,'a  SOURCE QUESTION AND ANNOTATED SUPPORT SET',9.5,weight='bold')
document(a,2,8,7,9,'q');document(a,13,8,7,9,'S₁','#CBE3D9');document(a,24,8,7,9,'S₂','#CBE3D9')
txt(a,37,11,'Every question contributes six views',8.3,weight='bold');txt(a,37,16,'Block A: 2 views     Block B: 4 views',8)
box(a,0,24,48,61,fill='blue',edge='#B1CADB');box(a,52,24,48,61,fill='teal',edge='#B0D2C7')
txt(a,3,28,'b  BLOCK A — TWO ALTERNATIVES',9,weight='bold')
txt(a,3,34,'A0  Compact support core',8,weight='bold');strip(a,4,38,['S₁','S₂']);strip(a,23,38,['S₁','R'])
txt(a,4,48,'Positive',7.3,color=SUP);txt(a,23,48,'Support replaced',7.3,color=NEG)
txt(a,3,55,'A1  Untouched BM25 prefixes',8,weight='bold')
txt(a,3,61,'12',7);strip(a,9,58,['D','S₁','D','D'],True)
txt(a,3,73,'40',7);strip(a,9,70,['D','S₁','D','S₂'],True)
txt(a,3,81,'Labels follow observed support coverage',7.4)
txt(a,55,28,'c  BLOCK B — MATCHED PAIRS',9,weight='bold')
txt(a,55,34,'B0  Random background',8,weight='bold');strip(a,56,38,['S₁','D','S₂','D','D'],True)
strip(a,56,49,['S₁','D','R','D','D'],True)
txt(a,55,61,'B1  BM25-selected background',8,weight='bold');strip(a,56,65,['D','S₁','S₂','D','D'],True)
txt(a,55,78,'Positive / negative pairs at k = 12 and 40',7.4)
box(a,0,90,100,21,fill='white',edge='#D5DFE7')
txt(a,3,94,'d  FOUR RECIPES',9,weight='bold')
for i,(m,formula) in enumerate([('CE','A0 + B0'),('NR','A1 + B0'),('CH','A0 + B1'),('NH','A1 + B1')]):
    x=4+i*24;box(a,x,98,20,6,m,'white',COL[m],9,'bold');txt(a,x+10,108,formula,8.3,ha='center')
txt(a,2,116,'32,556 views / fit  ·  3 matched seeds  ·  same binary cross-entropy objective',8.1,weight='bold')
txt(a,2,121,'CE / CH: 16,278 positive + 16,278 negative views',7.8)
txt(a,2,126,'NR / NH: 13,669 positive + 18,887 negative views',7.8)
txt(a,2,130,'S = support; D = background; R = replacement. Passage cards are schematic.',7.2,color=GRAY)
save(f,2)

# 3 — Exact gate computation and its operating rule.
f,a=schematic(6.4)
txt(a,0,3,'a  QUESTION–CONTEXT SCORE',10,weight='bold')
box(a,1,9,20,12,'Question q\nOrdered paragraphs Dₖ','blue',COL['NR'],8)
arr(a,(22,15),(27,15));box(a,28,9,28,12,'Qwen2.5-1.5B\nFrozen BF16 backbone','purple','#A291C0',8)
arr(a,(57,15),(62,15));box(a,63,9,18,12,'Final-token\nhidden state','blue','#9AB6CC',7.8)
arr(a,(82,15),(87,15));box(a,88,9,11,12,'No / Yes\nlogits','teal',SUP,7.5)
box(a,1,28,56,38,fill='#FAFBFC',edge='#C7D4DE')
txt(a,4,32,'b  LOW-RANK UPDATE ON q AND v',9.2,weight='bold')
txt(a,4,39,'x',10,weight='bold');route(a,[(8,39),(14,39),(14,42),(20,42)])
box(a,21,37,18,10,'Frozen W₀','gray',GRAY,8)
arr(a,(40,42),(49,42));a.add_patch(Circle((51,42),2.1,fc='white',ec=GRAY,lw=.8));txt(a,51,42,'+',10,ha='center')
route(a,[(14,39),(14,55),(20,55)],'#9B7AAF')
box(a,21,51,9,8,'A','purple','#A291C0',8.5,'bold');arr(a,(31,55),(35,55),'#9B7AAF')
box(a,36,51,9,8,'B','purple','#A291C0',8.5,'bold');route(a,[(46,55),(51,55),(51,45)],'#9B7AAF')
txt(a,4,63,r'$W_0x+(\alpha/r)BAx$     $r=8$, $\alpha=16$',8.3)
box(a,62,28,37,38,fill='#FBFAF7',edge='#DCCCB8')
txt(a,65,32,'c  INDEPENDENT CALIBRATION',8.8,weight='bold')
txt(a,65,40,r'$p=\mathrm{softmax}(z_{\mathrm{No}},z_{\mathrm{Yes}})_{\mathrm{Yes}}$',8.2)
txt(a,65,47,'τ = 80% positive-retention cutoff',7.8)
txt(a,65,54,'Calibration components set τ',7.8,color='#A37648')
txt(a,65,61,'Test components measure outcomes',7.8)
txt(a,1,73,'TRAINING',8.5,weight='bold');txt(a,22,73,'Mean binary cross-entropy over six views per source question',8)
txt(a,1,81,'DECISION',8.5,weight='bold');txt(a,22,81,'Accept when p ≥ τ; select from the same fixed reader answers',8)
txt(a,1,89,'MEASUREMENT',8.5,weight='bold');txt(a,22,89,'Coverage: AUROC, FAR, TPR    ·    Answers: EM, yield, risk–coverage',7.7)
save(f,3)

# 4 — Component separation and exact retrieval denominators.
f=base(4.1);a=axis(f,.05,.35,2.7,3.1);b=axis(f,3.55,.35,2.7,3.1)
a.set(xlim=(0,100),ylim=(100,0));a.axis('off');panel(a,'a','Independent source components')
box(a,1,2,98,19,'Clean pool\n2,528 questions / 2,325 components','blue',size=8.3)
arr(a,(50,23),(50,30));box(a,1,32,98,21,'Historical allocation: 1,600 questions\nUnscored remainder: 928 questions','gray',size=8)
arr(a,(35,55),(23,65));arr(a,(65,55),(77,65))
box(a,1,67,45,28,'Calibration\n300 questions\n276 components','orange',size=8)
box(a,54,67,45,28,'Test\n628 questions\n590 components','teal',size=8)
panel(b,'b','Retrieved support coverage')
den=list(csv.DictReader((SRC/'retrieval_coverage.csv').open(encoding='utf-8')))
for retr,col,marker,label in [('BM25',COL['CE'],'o','BM25'),('HYBRID_RRF',COL['NR'],'s','HYBRID')]:
    rr=[r for r in den if r['cohort']=='v6_unseen' and r['split']=='test' and r['retriever']==retr]
    b.plot([int(r['paragraphs']) for r in rr],[100*int(r['positive'])/628 for r in rr],marker=marker,color=col,label=label,ms=4)
b.set(xlabel='Retrieved paragraphs',ylabel='Complete support coverage (%)',xticks=[12,20,32,40],ylim=(60,93),yticks=[60,70,80,90]);clean(b);b.legend(loc='lower right',frameon=False)
save(f,4,[a,b])

# 5 — Distribution dependence is the decisive comparison, not a uniform win.
f=base(3.9);axs=[axis(f,.83,.45,2.22,2.55),axis(f,4.08,.45,2.22,2.55)]
controlled=list(csv.DictReader((SRC/'historical_controlled_auroc.csv').open(encoding='utf-8')))
labels=[['MuSiQue','HotpotQA','IIRC'],['Old BM25','New BM25','New HYBRID']]
for ax,letter,title in zip(axs,'ab',['Controlled contexts','Natural retrieval']):panel(ax,letter,title)
for j,m in enumerate(MAP):
    rr=[next(r for r in controlled if r['dataset']==ds and r['method']==m) for ds in labels[0]]
    axs[0].errorbar([float(r['AUROC_mean']) for r in rr],np.arange(3)+(j-1.5)*.12,xerr=[float(r['AUROC_seed_SD']) for r in rr],fmt=MARK[m],color=COL[m],ms=4,capsize=2,label=m)
    rr=[metric(m,cohort='v5_seen',retriever='BM25'),metric(m,retriever='BM25'),metric(m)]
    axs[1].errorbar([float(r['AUROC_mean']) for r in rr],np.arange(3)+(j-1.5)*.12,xerr=[float(r['AUROC_seed_SD']) for r in rr],fmt=MARK[m],color=COL[m],ms=4,capsize=2)
for ax,ls in zip(axs,labels):ax.set(yticks=range(3),yticklabels=ls,xlabel='AUROC',ylim=(2.5,-.5));clean(ax);ax.grid(axis='x',color='#E9EDF0',lw=.65)
axs[0].set_xlim(.82,1.005);axs[1].set_xlim(.65,.94)
f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=4,frameon=False,bbox_to_anchor=(.5,(10-3.48)/11))
save(f,5,axs)

# 6 — Retain every tested retrieval prefix, displaying fit variability.
f=base(3.65);axs=[axis(f,.65,.4,2.4,2.45),axis(f,3.95,.4,2.4,2.45)]
for ax,retr,letter,title in zip(axs,['BM25','HYBRID_RRF'],'ab',['New BM25','New HYBRID']):
    panel(ax,letter,title)
    for m in MAP:
        rr=[metric(m,retriever=retr,condition=f'n{k}') for k in [12,20,32,40]]
        y=np.array([float(r['AUROC_mean']) for r in rr]);s=np.array([float(r['AUROC_seed_SD']) for r in rr])
        ax.errorbar([12,20,32,40],y,yerr=s,fmt=MARK[m]+'-',color=COL[m],ms=4,capsize=2,lw=1.2,label=m)
    ax.set(xlabel='Retrieved paragraphs',xticks=[12,20,32,40],xlim=(9,43),ylim=(.60,.96),yticks=[.6,.7,.8,.9]);clean(ax)
axs[0].set_ylabel('Coverage AUROC');f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=4,frameon=False,bbox_to_anchor=(.5,(10-3.20)/11));save(f,6,axs)

# Raw records used for ROC and score CDF. No sampling or smoothing.
scores={};raw_rows=[]
if PORTABLE:
    raw_rows=list(csv.DictReader((SRC/'primary_test_scores.csv').open(encoding='utf-8')))
    for m in MAP:
        for seed in [11,29,47]:
            rr=[r for r in raw_rows if r['recipe']==m and int(r['seed'])==seed];assert len(rr)==628
            scores[m,seed]=np.array([float(r['probability']) for r in rr])
    y=np.array([int(r['label']) for r in raw_rows if r['recipe']=='CE' and int(r['seed'])==11])
else:
    plan=[json.loads(x) for x in (RAW/'evaluation_plan.jsonl').read_text(encoding='utf-8-sig').splitlines()]
    idx=np.array([i for i,r in enumerate(plan) if r['cohort']=='v6_unseen' and r['retriever']=='HYBRID_RRF' and r['split']=='test' and r['condition']=='n40'])
    assert len(idx)==628
    y=np.array([plan[i]['label'] for i in idx])
    for m in MAP:
        for seed in [11,29,47]:
            with np.load(RAW/f'score_cache/{MAP[m]}_seed{seed}.npz',allow_pickle=False) as z:scores[m,seed]=z['probability'][idx].copy()
            for i,p in zip(idx,scores[m,seed]):raw_rows.append(dict(sample_id=plan[i]['sample_id'],component_id=plan[i]['component_id'],label=plan[i]['label'],recipe=m,seed=seed,probability=p))
    with (SUPPORT/'source_data/primary_test_scores.csv').open('w',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(raw_rows[0]));writer.writeheader();writer.writerows(raw_rows)
assert len(y)==628 and y.sum()==548
def roc(labels,prob):
    order=np.argsort(-prob,kind='stable');p=prob[order];truth=labels[order]
    ends=np.r_[np.where(np.diff(p)!=0)[0],len(p)-1]
    tp=np.cumsum(truth)[ends];fp=(ends+1)-tp
    return np.r_[0,fp/(len(truth)-sum(truth))],np.r_[0,tp/sum(truth)]

# 7 — The full discrimination curve of each matched fit is visible.
f=base(3.4);axs=[axis(f,.48+i*2.15,.4,1.55,2.1) for i in range(3)]
for ax,seed,letter in zip(axs,[11,29,47],'abc'):
    panel(ax,letter,f'Seed {seed}')
    for m in MAP:
        xx,yy=roc(y,scores[m,seed]);ax.step(xx,yy,where='post',color=COL[m],lw=1.3,label=m)
    ax.plot([0,1],[0,1],color='#AAB5BD',lw=.8,ls='--');ax.set(xlim=(0,1),ylim=(0,1.02),xticks=[0,.5,1],yticks=[0,.5,1],xlabel='False positive rate');clean(ax)
axs[0].set_ylabel('True positive rate');f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=4,frameon=False,bbox_to_anchor=(.5,(10-2.9)/11));save(f,7,axs)

# 8 — Operating policies, with both decision consequences.
f=base(3.9);axs=[axis(f,.65,.4,2.4,2.55),axis(f,3.95,.4,2.4,2.55)]
policies=['source_mu12','target12','target40','bm25_target40_transfer','fixed_half']
for ax,field,title,letter in zip(axs,['FAR','TPR'],['False acceptance','Positive retention'],'ab'):
    panel(ax,letter,title)
    for j,m in enumerate(MAP):
        rr=[metric(m,policy=p) for p in policies]
        ax.errorbar(np.arange(5)+(j-1.5)*.1,[100*float(r[field+'_mean']) for r in rr],yerr=[100*float(r[field+'_seed_SD']) for r in rr],fmt=MARK[m]+'-',color=COL[m],ms=3.5,capsize=1.6,lw=.9,label=m)
    ax.set(xticks=range(5),xticklabels=['Source\n12','Target\n12','Target\n40','BM25\ntransfer','Fixed\n0.5'],ylim=(-3,104),yticks=[0,25,50,75,100],ylabel=field+' (%)');clean(ax)
f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=4,frameon=False,bbox_to_anchor=(.5,(10-3.45)/11));save(f,8,axs)

# 9 — All four frozen paired endpoints and both uncertainty levels.
f=base(3.6);axs=[axis(f,.83,.4,2.2,2.1),axis(f,4.1,.4,2.2,2.1)]
for ax,field,title,letter in zip(axs,['FAR','TPR'],['False acceptance contrast','Positive retention contrast'],'ab'):
    panel(ax,letter,title)
    for j,p in enumerate(['source_mu12','target40']):
        r=next(r for r in primary['endpoints'] if r['policy']==p and r['metric']==field)
        ax.plot(100*np.array(r['CI_family4']),[j,j],color='#A2B7C6',lw=1.7)
        ax.plot(100*np.array(r['CI95']),[j,j],color=COL['NR'],lw=4,solid_capstyle='butt');ax.plot(100*r['difference'],j,'s',color=COL['NR'],ms=5)
    ax.axvline(0,color='#6E7B85',ls='--',lw=.8)
    if field=='TPR':ax.axvline(-2,color=NEG,ls=':',lw=1.2)
    ax.set(yticks=[0,1],yticklabels=['Source 12','Target 40'],ylim=(1.6,-.6),xlim=(-72,14),xticks=[-60,-40,-20,0],xlabel='NR − CE (percentage points)');clean(ax);ax.grid(axis='x',color='#E9EDF0',lw=.65)
f.legend(handles=[Line2D([0],[0],color=COL['NR'],lw=4,label='95% interval'),Line2D([0],[0],color='#A2B7C6',lw=1.7,label='98.75% adjusted interval'),Line2D([0],[0],color=NEG,ls=':',label='Retention margin: −2 pp')],loc='upper center',ncol=1,frameon=False,bbox_to_anchor=(.5,(10-2.95)/11),fontsize=7.5);save(f,9,axs)

# 10 — Class score distributions distinguish a ranking from its score scale.
f=base(6.3);axs=[axis(f,.65+(i%2)*3.3,.45+(i//2)*2.7,2.4,2.05) for i in range(4)]
grid=np.unique(np.concatenate([np.array([0.,1.])]+list(scores.values())))
for ax,m,letter in zip(axs,MAP,'abcd'):
    panel(ax,letter,m)
    for label,col,name,style in [(1,SUP,'Coverage positive','-'),(0,NEG,'Coverage negative','--')]:
        values=np.array([np.searchsorted(np.sort(scores[m,s][y==label]),grid,side='right')/sum(y==label) for s in [11,29,47]])
        mean=values.mean(axis=0);sd=values.std(axis=0,ddof=1)
        ax.step(grid,mean,where='post',color=col,ls=style,lw=1.3,label=name)
        ax.fill_between(grid,np.maximum(mean-sd,0),np.minimum(mean+sd,1),step='post',color=col,alpha=.12,lw=0)
    ax.set(xlim=(0,1),ylim=(0,1.02),xticks=[0,.5,1],yticks=[0,.5,1],xlabel='Gate score');clean(ax)
for ax in [axs[0],axs[2]]:ax.set_ylabel('Empirical cumulative fraction')
f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,(10-5.9)/11));save(f,10,axs)

# 11 — Fixed answers, complete stored display curves, three target settings.
f=base(3.55);axs=[axis(f,.48+i*2.15,.4,1.55,2.15) for i in range(3)]
for ax,(cohort,retr,title),letter in zip(axs,[('v5_seen','BM25','Old BM25'),('v6_unseen','BM25','New BM25'),('v6_unseen','HYBRID_RRF','New HYBRID')],'abc'):
    panel(ax,letter,title)
    for m in MAP:
        rr=[r for r in curves if r['method']==MAP[m] and r['cohort']==cohort and r['retriever']==retr and r['condition']=='n40'];assert len(rr)==3
        xx=np.array([p['answer_acceptance'] for p in rr[0]['points']]);vv=np.array([[p['EM_unmatched_risk'] for p in r['points']] for r in rr])
        mean=vv.mean(axis=0);sd=vv.std(axis=0,ddof=1);ax.plot(xx,mean,color=COL[m],lw=1.2,label=m);ax.fill_between(xx,mean-sd,mean+sd,color=COL[m],alpha=.10,lw=0)
    ax.axhline(rr[0]['random_expected_risk'],color='#8E9BA5',lw=.9,ls='--',label='Random')
    ax.set(xlim=(0,1),ylim=(0,.95),xticks=[0,.5,1],yticks=[0,.3,.6,.9],xlabel='Answer acceptance');clean(ax)
axs[0].set_ylabel('EM-unmatched risk');f.legend(*axs[0].get_legend_handles_labels(),loc='upper center',ncol=5,frameon=False,bbox_to_anchor=(.5,(10-3.05)/11));save(f,11,axs)

if Path(__file__).resolve()!=(SUPPORT/'redraw_figures.py').resolve():copy2(Path(__file__),SUPPORT/'redraw_figures.py')
print('Saved 11 vector figure PDFs, editable SVGs, PNGs and numerical sources.')
