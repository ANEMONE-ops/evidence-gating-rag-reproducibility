"""Reconstruct every selected token hash, then optionally run all twelve fits.

Run from the extracted Supplemental Data S3 directory. Requires S2 alongside it.
Frozen optimization code is reused; no original model or results are overwritten.
"""
from pathlib import Path
import argparse, hashlib, json, os, sys
import numpy as np

HERE=Path(__file__).resolve().parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def rows(p):return [json.loads(x) for x in p.read_text(encoding='utf-8-sig').splitlines() if x.strip()]
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--s2',type=Path,default=HERE.parent/'Supplemental_Data_S2')
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--train',action='store_true',help='After token-hash verification, run all 12 GPU fits.')
    args=p.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
    from restore_inputs import restore
    restore(HERE,args.s2)
    training=HERE/'training';sys.path.insert(0,str(training))
    from core import messages
    from tasks import documents
    from transformers import AutoTokenizer
    revision='989aa7980e4cf806f80c7fef2b1adb7bc71aa306'
    tokenizer=AutoTokenizer.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision=revision,trust_remote_code=False)
    corpus=read(args.s2/'code/data/hot_corpus.json');corpus.update(read(training/'source_corpus.json'))
    plan=rows(training/'plan.jsonl');groups={g['group_id']:g for g in rows(training/'groups.jsonl')}
    metadata={r['sample_id']:r for r in rows(training/'record_metadata.jsonl')}
    offset=0
    token_path=out/'token_ids.bin'
    with token_path.open('wb') as stream:
        for i,r in enumerate(plan):
            g=groups[r['group_id']]
            docs=[corpus[k] for k in metadata[r['sample_id']]['document_keys']] if r['sample_id'] in metadata else documents(g,corpus,r['condition'],r['label'])
            ids=tokenizer.apply_chat_template(messages(g['question'],docs),tokenize=True,add_generation_prompt=True)
            blob=np.asarray(ids,dtype='<i4').tobytes()
            assert hashlib.sha256(blob).hexdigest()==r['input_sha256'],r['sample_id']
            assert len(ids)==r['tokens']
            r['offset']=offset;stream.write(blob);offset+=len(ids)
            if (i+1)%5000==0:print('Verified token hashes',i+1,'/',len(plan),flush=True)
    (out/'verified_plan.json').write_text(json.dumps(plan,ensure_ascii=False),encoding='utf-8')
    (out/'input_verification.json').write_text(json.dumps(dict(rows=len(plan),all_hashes_match=True,total_tokens=offset,train_requested=args.train),indent=2),encoding='utf-8')
    if not args.train:return
    # Load the fixed public revision before the historical module enables offline mode.
    import torch
    from transformers import AutoModelForCausalLM
    assert torch.cuda.is_available(),'A CUDA GPU is required for fitting.'
    torch.set_num_threads(8);torch.manual_seed(20261025)
    model=AutoModelForCausalLM.from_pretrained('Qwen/Qwen2.5-1.5B-Instruct',revision=revision,torch_dtype=torch.bfloat16,attn_implementation='sdpa',trust_remote_code=False).to('cuda:0')
    import run_v3 as train
    import adapters,tasks
    adapters.install(model,8,16)
    cfg=read(training/'original_protocol.json')
    tokens=np.memmap(token_path,mode='r',dtype='<i4')
    maps=rows(training/'four_corner_training_maps.jsonl')
    methods=['CE','NAT_RANDOM_CE','CORE_HARD_CE','RET_CE']
    for method in methods:tasks.METHODS[method]=[]
    q=0
    for method in methods:
        use=[dict(g,global_rows=g['global_rows_by_method'][method]) for g in maps]
        assert len(use)==5426 and sum(len(g['global_rows']) for g in use)==32556
        for seed in [11,29,47]:
            train.train_one(model,tokens,plan,use,cfg,out,method,seed,q);q+=1
    print('All twelve construction fits completed.',flush=True)
if __name__=='__main__':main()
