"""Restore original JSONL bytes from lossless passage-key dictionaries."""
from pathlib import Path
import hashlib,json,re
def restore_corpora(root):
 root=Path(root)
 spec=json.loads((root/'corpus_storage.json').read_text(encoding='utf-8'))
 for relative,item in spec['files'].items():
  p=root/relative
  if p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==item['decoded_sha256']:continue
  values=json.loads((root/item['values_file']).read_text(encoding='utf-8'))
  data={hashlib.sha256((v['title'].strip()+'\n'+v['text'].strip()).encode('utf-8')).hexdigest():v for v in values}
  assert len(data)==item['passages']
  b=(json.dumps(data,ensure_ascii=False,indent=2,allow_nan=False)+'\n').replace('\n','\r\n').encode('utf-8')
  assert hashlib.sha256(b).hexdigest()==item['decoded_sha256'],relative
  p.write_bytes(b)

def restore(root,s2=None):
 root=Path(root);s2=Path(s2) if s2 else root
 restore_corpora(s2)
 if root!=s2:restore_corpora(root)
 spec=json.loads((root/'passage_key_codec.json').read_text(encoding='utf-8'))
 corpus=json.loads((s2/'code/data/hot_corpus.json').read_text(encoding='utf-8'))
 corpus.update(json.loads((root/spec['source_corpus']).read_text(encoding='utf-8')))
 keys=list(corpus)
 def decode(v):
  if isinstance(v,str) and re.fullmatch(r'@[0-9]+',v):return keys[int(v[1:])]
  if isinstance(v,list):return [decode(x) for x in v]
  if isinstance(v,dict):return {k:decode(x) for k,x in v.items()}
  return v
 for relative,item in spec['files'].items():
  dest=root/relative
  if dest.exists() and hashlib.sha256(dest.read_bytes()).hexdigest()==item['decoded_sha256']:continue
  temporary=dest.with_suffix('.restore.tmp')
  with (root/item['indexed_file']).open(encoding='utf-8') as src, temporary.open('w',encoding='utf-8',newline='\n') as out:
   for line in src:out.write(json.dumps(decode(json.loads(line)),ensure_ascii=False,separators=(',',':'))+'\n')
  assert hashlib.sha256(temporary.read_bytes()).hexdigest()==item['decoded_sha256'],relative
  temporary.replace(dest)
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--s2',type=Path);a=p.parse_args();restore(Path(__file__).resolve().parent,a.s2)
